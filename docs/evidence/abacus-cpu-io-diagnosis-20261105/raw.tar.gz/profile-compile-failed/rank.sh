#!/usr/bin/env bash
set -eu
trace=${SAI_DIAG_CASE:?}/ranks/${OMPI_COMM_WORLD_RANK:?}
date +%s.%N > "$trace.start"
cat /proc/self/status > "$trace.status"
cat /proc/self/cgroup > "$trace.cgroup"
if [[ -n ${SAI_PROFILE_LIB:-} ]]; then
    export LD_PRELOAD=$SAI_PROFILE_LIB
    if [[ "$OMPI_COMM_WORLD_RANK" == 0 || "$OMPI_COMM_WORLD_RANK" == 4 ]]; then
        /usr/bin/time -v -o "$trace.time" strace -f -ttt -T -e trace=openat,newfstatat,statx,unlink,unlinkat,rename,mkdir,rmdir,ftruncate,fallocate,fsync,fdatasync,nanosleep,clock_nanosleep -o "$trace.strace" bash "$@"
    else
        /usr/bin/time -v -o "$trace.time" bash "$@"
    fi
else
    /usr/bin/time -v -o "$trace.time" bash "$@"
fi
date +%s.%N > "$trace.end"
