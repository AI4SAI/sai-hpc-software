#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
static double begin=0;static int rank=-1;static long count[24];static double total[24],maximum[24];static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static const char* names[]={"Init","Init_thread","Finalize","Barrier","Allreduce","Reduce","Bcast","Comm_split","Comm_split_type","Comm_dup","Comm_free","Alltoall","Alltoallv","Allgather","Allgatherv","Wait","Waitall","Send","Recv","Sendrecv"};
struct event{int type;double start,duration;};static struct event events[2048];static int nev;
static double wall(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void record(int i,double start){double d=wall()-start;pthread_mutex_lock(&lock);count[i]++;total[i]+=d;if(d>maximum[i])maximum[i]=d;if(d>0.1&&nev<2048)events[nev++]=(struct event){i,start-begin,d};pthread_mutex_unlock(&lock);}
#define WRAP(i,name,decl,args) int MPI_##name decl{double t=wall();int rc=PMPI_##name args;record(i,t);return rc;}
int MPI_Init(int *argc,char ***argv){begin=wall();double t=wall();int rc=PMPI_Init(argc,argv);PMPI_Comm_rank(MPI_COMM_WORLD,&rank);record(0,t);return rc;}
int MPI_Init_thread(int *argc,char ***argv,int req,int *prov){begin=wall();double t=wall();int rc=PMPI_Init_thread(argc,argv,req,prov);PMPI_Comm_rank(MPI_COMM_WORLD,&rank);record(1,t);return rc;}
int MPI_Finalize(void){double t=wall();int rc=PMPI_Finalize();record(2,t);const char *root=getenv("SAI_DIAG_CASE");if(root){char path[4096];snprintf(path,sizeof(path),"%s/ranks/%d.mpi-profile.json",root,rank);FILE *f=fopen(path,"w");if(f){fprintf(f,"{\"rank\":%d,\"lifetime_seconds\":%.9f,\"calls\":[",rank,wall()-begin);for(int i=0;i<20;i++){if(i)fputs(",",f);fprintf(f,"{\"name\":\"%s\",\"count\":%ld,\"seconds\":%.9f,\"max_seconds\":%.9f}",names[i],count[i],total[i],maximum[i]);}fputs("],\"long_calls\":[",f);for(int i=0;i<nev;i++){if(i)fputs(",",f);fprintf(f,"{\"name\":\"%s\",\"start_seconds\":%.9f,\"seconds\":%.9f}",names[events[i].type],events[i].start,events[i].duration);}fputs("]}\n",f);fclose(f);}}return rc;}
WRAP(3,Barrier,(MPI_Comm c),(c))
WRAP(4,Allreduce,(const void*s,void*r,int n,MPI_Datatype d,MPI_Op o,MPI_Comm c),(s,r,n,d,o,c))
WRAP(5,Reduce,(const void*s,void*r,int n,MPI_Datatype d,MPI_Op o,int root,MPI_Comm c),(s,r,n,d,o,root,c))
WRAP(6,Bcast,(void*b,int n,MPI_Datatype d,int root,MPI_Comm c),(b,n,d,root,c))
WRAP(7,Comm_split,(MPI_Comm c,int color,int key,MPI_Comm *out),(c,color,key,out))
WRAP(8,Comm_split_type,(MPI_Comm c,int type,int key,MPI_Info info,MPI_Comm*out),(c,type,key,info,out))
WRAP(9,Comm_dup,(MPI_Comm c,MPI_Comm*out),(c,out))
WRAP(10,Comm_free,(MPI_Comm*c),(c))
WRAP(11,Alltoall,(const void*s,int sn,MPI_Datatype st,void*r,int rn,MPI_Datatype rt,MPI_Comm c),(s,sn,st,r,rn,rt,c))
WRAP(12,Alltoallv,(const void*s,const int*sn,const int*sd,MPI_Datatype st,void*r,const int*rn,const int*rd,MPI_Datatype rt,MPI_Comm c),(s,sn,sd,st,r,rn,rd,rt,c))
WRAP(13,Allgather,(const void*s,int sn,MPI_Datatype st,void*r,int rn,MPI_Datatype rt,MPI_Comm c),(s,sn,st,r,rn,rt,c))
WRAP(14,Allgatherv,(const void*s,int sn,MPI_Datatype st,void*r,const int*rn,const int*rd,MPI_Datatype rt,MPI_Comm c),(s,sn,st,r,rn,rd,rt,c))
WRAP(15,Wait,(MPI_Request*r,MPI_Status*s),(r,s))
WRAP(16,Waitall,(int n,MPI_Request*r,MPI_Status*s),(n,r,s))
WRAP(17,Send,(const void*b,int n,MPI_Datatype t,int dst,int tag,MPI_Comm c),(b,n,t,dst,tag,c))
WRAP(18,Recv,(void*b,int n,MPI_Datatype t,int src,int tag,MPI_Comm c,MPI_Status*s),(b,n,t,src,tag,c,s))
WRAP(19,Sendrecv,(const void*sb,int sn,MPI_Datatype st,int dst,int stag,void*rb,int rn,MPI_Datatype rt,int src,int rtag,MPI_Comm c,MPI_Status*s),(sb,sn,st,dst,stag,rb,rn,rt,src,rtag,c,s))
