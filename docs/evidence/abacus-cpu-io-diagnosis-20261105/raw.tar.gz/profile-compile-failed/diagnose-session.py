from pathlib import Path
import os,json,subprocess,time,shutil,re,hashlib
root=Path.cwd(); source=Path('/org/org-open-sai/proj-sai-hpc-software/runtime-tests/abacus-beta12-physical-20261105-190518-384810/DSPRHBM')
hosts=subprocess.check_output(['scontrol','show','hostnames',os.environ['SLURM_JOB_NODELIST']],text=True).split(); (root/'nodes.json').write_text(json.dumps(hosts))
for n,args in [('allocation',['scontrol','show','job','-dd',os.environ['SLURM_JOB_ID']]),('mpi-shmem',['ompi_info','--param','shmem','all','--level','9']),('mpi-btl',['ompi_info','--param','btl','sm','--level','9']),('mpi-coll',['ompi_info','--param','coll','all','--level','9'])]:
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=20);(root/(n+'.txt')).write_text(p.stdout)
subprocess.run(['mpicc','-shared','-fPIC','-O2','-pthread',str(root/'mpi-profile.c'),'-o',str(root/'mpi-profile.so')],check=True)
ram='/dev/shm/sai-abacus-mpi-'+str(os.getuid())+'-'+os.environ['SLURM_JOB_ID']
subprocess.run(['srun','--overlap','--nodes=2','--ntasks=2','--ntasks-per-node=1','--cpus-per-task=1','bash','-c','umask 077; mkdir -- "$1"','bash',ram],check=True)
probe="hostname; cat /proc/self/status; cat /proc/self/cgroup; cat /proc/loadavg; df -h /dev/shm; env | sort | grep -E '^(OMPI|PRTE|PMIX|UCX|OMP|SLURM|TMP)'; command -v strace; command -v perf; command -v gdb"
p=subprocess.run(['srun','--overlap','--nodes=2','--ntasks=2','--ntasks-per-node=1','--cpus-per-task=8','--cpu-bind=none','bash','-c',probe],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30);(root/'slurm-cpu-context.txt').write_text(p.stdout)
(root/'environment.json').write_text(json.dumps({k:v for k,v in os.environ.items() if k.startswith(('OMPI','PRTE','PMIX','UCX','OMP','SLURM','TMP','MKL','OPENBLAS'))},indent=2))
rows=[]
for seq,(mode,case) in enumerate([('session-shm','deepks'),('original','deepks'),('session-shm','deepks'),('session-shm','hse'),('original-profiled','deepks'),('session-shm-profiled','deepks')]):
 p=root/f'{seq:02}-{mode}-{case}';p.mkdir();(p/'ranks').mkdir()
 if case != 'probe':
  for f in (source/'inputs'/case).rglob('*'):
   if f.is_file(): t=p/f.relative_to(source/'inputs'/case);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
 env=dict(os.environ,SAI_NATIVE_TRACE=str(p/'ranks'),SAI_DIAG_CASE=str(p));env.pop('OMPI_MCA_shmem_mmap_backing_file_base_dir',None);env.pop('OMPI_MCA_shmem_mmap_relocate_backing_file',None)
 if mode.startswith('session-shm'):env.update(OMPI_MCA_shmem_mmap_backing_file_base_dir='/dev/shm',OMPI_MCA_shmem_mmap_relocate_backing_file='1',PRTE_MCA_prte_tmpdir_base=ram)
 if mode.endswith('-profiled'):env['SAI_PROFILE_LIB']=str(root/'mpi-profile.so')
 exe=['bash',str(root/'rank.sh'),str(source/'control/native-rank.sh')] if case != 'probe' else [str(root/'mpi-probe')]
 cmd=['mpirun','-np','8','--host',','.join(h+':4' for h in hosts),'--map-by','ppr:4:node:PE=2','--bind-to','core','--report-bindings',*exe]
 print('START',p.name,flush=True);begin=time.monotonic()
 with (p/'stdout.log').open('w') as f:
  process=subprocess.Popen(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try: rc=process.wait(timeout=360)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(process.pid,signal.SIGTERM)
   try:rc=process.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);rc=process.wait()
 row=dict(seq=seq,mode=mode,case=case,returncode=rc,wall_seconds=time.monotonic()-begin,command=cmd,job=os.environ['SLURM_JOB_ID'])
 text=(p/'stdout.log').read_text(errors='replace');m=re.search(r'^\s+total\s+(\d+(?:\.\d+)?)\s',text,re.M);row['abacus_total_seconds']=float(m[1]) if m else None
 row['shared_memory_warning']='Space Available: 0 B' in text
 if case!='probe':
  logs=list(p.glob('OUT.*/running_scf.log'));out=logs[0].read_text(errors='replace') if logs else '';m=re.search(r'!FINAL_ETOT_IS\s+([-+0-9.eE]+)',out);row['energy_ev']=float(m[1]) if m else None
 (p/'result.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print('DONE',json.dumps(row),flush=True)
 if rc!=0:break

subprocess.run(['srun','--overlap','--nodes=2','--ntasks=2','--ntasks-per-node=1','--cpus-per-task=1','bash','-c','test -d "$1" && test -O "$1" && find "$1" -maxdepth 2 -printf "%p %s bytes\n"','bash',ram],stdout=(root/'ram-final-files.txt').open('w'),stderr=subprocess.STDOUT,timeout=30)
