#!/usr/bin/env bash
set -eu
trace=${SAI_DIAG_CASE:?}/ranks/${OMPI_COMM_WORLD_RANK:?}
date +%s.%N > "$trace.start"
cat /proc/self/status > "$trace.status"
cat /proc/self/cgroup > "$trace.cgroup"
/usr/bin/time -v -o "$trace.time" bash "$@"
date +%s.%N > "$trace.end"
