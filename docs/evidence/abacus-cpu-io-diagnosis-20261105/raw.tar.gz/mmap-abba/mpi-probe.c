#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec*1e-9; }
int main(int argc,char **argv){
 double start=now();MPI_Init(&argc,&argv);double init=now()-start;int rank,n;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&n);
 double x=rank+1,y=0;MPI_Barrier(MPI_COMM_WORLD);start=now();for(int i=0;i<1000;++i)MPI_Allreduce(&x,&y,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);double small=now()-start;
 int count=131072;double *a=calloc(count,sizeof(double)),*b=calloc(count,sizeof(double));for(int i=0;i<count;++i)a[i]=x;
 MPI_Barrier(MPI_COMM_WORLD);start=now();for(int i=0;i<20;++i)MPI_Allreduce(a,b,count,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);double large=now()-start;
 printf("rank=%d size=%d init_s=%.9f allreduce_8B_1000_s=%.9f allreduce_1MiB_20_s=%.9f value=%g\n",rank,n,init,small,large,y);fflush(stdout);free(a);free(b);MPI_Finalize();return 0;
}
