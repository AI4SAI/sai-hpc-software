"""Continue original frozen ABACUS acceptance on a fresh healthy allocation."""
from pathlib import Path
import json, os, subprocess, sys, traceback
ROOT = Path('/org/org-open-sai/proj-sai-hpc-software')
RUN = '41583854521-1-release-8v100v0-avx512-2026-11-03-6b24db05dc17'
HERE = ROOT / 'operations/abacus-ecc-recovery-20261103'
original = ROOT / 'runtime-tests' / (RUN + '-multinode')
request = json.loads((original / 'request.json').read_text())
control = Path(request['launcher']).parent
# Frozen controllers have no exclusion CLI. Add only this Slurm placement
# option at submission; retain their generated scripts and all verifiers.
wrapper = r'''
import json,runpy,subprocess,sys
from pathlib import Path
original_run = subprocess.run
script = sys.argv[2]
submission_log = sys.argv[1]
# Capture the log independently of the frozen controller's sys.argv.
def placed(argv, *args, **kwargs):
    if isinstance(argv, (list, tuple)) and str(argv[0]) == 'sbatch':
        argv = [argv[0], '--exclude=8v100v0n09', *argv[1:]]
        with Path(submission_log).open('a') as stream:
            stream.write(json.dumps(list(map(str, argv))) + '\n')
    return original_run(argv, *args, **kwargs)
subprocess.run = placed
sys.path.insert(0,str(Path(script).parent))
sys.argv = sys.argv[2:]
runpy.run_path(script, run_name='__main__')
'''
def command(script, *args):
    print('CONTINUE', script, *args, flush=True)
    subprocess.run([sys.executable, '-B', '-c', wrapper, str(HERE / 'submissions.jsonl'),
                    str(control / script), *args], check=True,
                   env=dict(os.environ, SAI_SOFTWARE_ROOT=str(ROOT), PYTHONDONTWRITEBYTECODE='1'))
try:
    command('runtime_controller.py', 'monitor', RUN + '-multinode-ecc-retry1', '--timeout', '3600')
    feature = RUN + '-gpu-features-ecc-retry1'
    if not (ROOT / 'runtime-tests' / feature / 'job.id').exists():
        command('gpu_feature_controller.py', 'submit', feature, request['version'], request['target'], '--build-run-id', RUN)
    command('gpu_feature_controller.py', 'monitor', feature, '--timeout', '3600')
    for case in ('pw', 'hse', 'deepks'):
        selected = RUN + '-' + case + '-ecc-retry1'
        directory = ROOT / 'runtime-tests' / ('benchmark-' + selected)
        if not directory.exists():
            command('abacus_benchmark.py', 'prepare', selected, request['version'], request['target'],
                    '--artifact', request['artifact'], '--launcher', request['launcher'],
                    '--system-module', 'abacus/v3.9.0.26-sm70-auto', '--packaged-case', case, '--allow-cpu-case-on-gpu')
        if not (directory / 'job.id').exists():
            command('abacus_benchmark.py', 'submit', selected)
        command('abacus_benchmark.py', 'monitor', selected, '--timeout', '7200')
    command('software_controller.py', 'publish', RUN)
    (HERE / 'status.json').write_text(json.dumps(dict(passed=True, build_run=RUN)) + '\n')
except Exception as error:
    (HERE / 'status.json').write_text(json.dumps(dict(passed=False, build_run=RUN, error=str(error))) + '\n')
    traceback.print_exc()
    raise
