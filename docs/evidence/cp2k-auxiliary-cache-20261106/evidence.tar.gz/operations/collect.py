"""Revalidate completed cold/warm runs and archive their small raw evidence."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

operation = Path(__file__).resolve().parent
config = json.loads((operation / 'config.json').read_text())
project, control = Path(config['project']), Path(config['controller'])
assert operation == Path(config['operation'])
os.environ['SAI_SOFTWARE_ROOT'] = str(project)
sys.dont_write_bytecode = True
sys.path.insert(0, str(control))
from source_cache import checksum
from software_controller import recipe_fingerprint
from cp2k_acceptance import verify_evidence, compare_science
from cp2k_auxiliary_cache import validate_bundle


def read(path):
    return json.loads(path.read_text())


files = {}


def retain(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert name not in files or files[name] == path
    files[name] = path


rows, pairs, jobs = [], {}, []
for case in config['cases']:
    phases = {}
    for phase in ('cold', 'warm'):
        run_id = 'cp2k-aux-20261106-' + config['commit'][:12] + '-' + case['name'] + '-' + phase
        run = project / 'runs' / run_id
        science = project / 'runtime-tests' / (run_id + '-science')
        request = read(run / 'request.json')
        assert request['controller'] == str(control)
        assert request['recipe_sha256'] == recipe_fingerprint('cp2k', control)
        assert read(run / 'results/status.json')['verified'] is True
        assert read(science / 'results/status.json')['verified'] is True
        artifact = Path((run / 'artifact.path').read_text().strip())
        manifest = read(artifact.with_suffix('.json'))
        assert manifest['published'] and manifest['verified']
        assert checksum(artifact) == manifest['sha256']
        proof = manifest['cp2k_science']
        assert proof['verified'] and proof['artifact_sha256'] == manifest['sha256']
        assert checksum(science / 'results/evidence.json') == proof['evidence_sha256']
        scientific = verify_evidence(science, read(science / 'request.json'))
        assert scientific == read(science / 'results/evidence.json')
        assert len(scientific['samples']) == 14 and len(scientific['comparisons']) == 7
        receipt = read(run / 'results/auxiliary-cache.json')
        assert receipt['enabled'] and receipt['hit'] == (phase == 'warm')
        assert receipt['prefix'] == request['identity']['install_prefix']
        cache_path = project / 'cache/cp2k-auxiliary' / receipt['key']
        cache = validate_bundle(cache_path, receipt['contract'])
        assert cache['archive_sha256'] == receipt['cache_archive_sha256']
        overlays = []
        for path in sorted((run / 'results').glob('managed-overlay-*.json')):
            record = read(path)
            assert record['accepted'] and record['completed'] and not record['forced_stop'], record
            assert record['payload_returncode'] == 0
            overlays.append(record)
        assert len(overlays) >= 2
        build_job = (run / 'job.id').read_text().strip()
        science_job = (science / 'job.id').read_text().strip()
        jobs += [build_job, science_job]
        base = 'builds/' + case['name'] + '/' + phase
        for name in ('request.json', 'job.sbatch', 'job.id', 'artifact.path'):
            retain(run / name, base + '/' + name)
        for path in sorted((run / 'results').rglob('*')):
            if path.is_file():
                retain(path, base + '/' + str(path.relative_to(run)))
        retain(artifact.with_suffix('.json'), base + '/artifact.json')
        sci_base = 'science/' + case['name'] + '/' + phase
        for name in sorted(set(scientific['files']) | {'results/evidence.json', 'results/status.json'}):
            retain(science / name, sci_base + '/' + name)
        for name in ('manifest.json', 'accepted.json'):
            retain(cache_path / name, 'cache/' + receipt['key'] + '/' + name)
        phases[phase] = dict(receipt=receipt, science=scientific)
        rows.append(dict(case=case['name'], phase=phase, run_id=run_id,
                         build_job=build_job, science_job=science_job,
                         identity=request['identity'], artifact=str(artifact),
                         artifact_sha256=manifest['sha256'], artifact_bytes=artifact.stat().st_size,
                         cache={name: value for name, value in receipt.items() if name != 'contract'},
                         cache_bytes=cache['archive_bytes'], cache_components=cache['components'],
                         overlays=overlays, science_evidence_sha256=proof['evidence_sha256'],
                         rank_comparisons=scientific['comparisons'],
                         solver_comparisons=scientific['solver_comparisons']))
        print('VERIFIED', case['name'], phase, build_job, science_job, flush=True)
    cold, warm = phases['cold'], phases['warm']
    assert cold['receipt']['key'] == warm['receipt']['key']
    assert cold['receipt']['prefix'] != warm['receipt']['prefix']
    assert warm['receipt']['origin']['prefix'] == cold['receipt']['prefix']
    assert set(warm['receipt']['timings']) == {'cp2k'}
    pairs[case['name']] = {
        name: compare_science(warm['science']['samples'][name], cold['science']['samples'][name])
        for name in cold['science']['samples']}

fields = ['JobIDRaw', 'State', 'ExitCode', 'Elapsed', 'ElapsedRaw', 'AllocCPUS', 'CPUTimeRAW',
          'NodeList', 'Account', 'Partition', 'AllocTRES', 'Start', 'End', 'Timelimit']
accounting = subprocess.check_output(['sacct', '-X', '-nP', '-j', ','.join(jobs),
                                      '-o', ','.join(fields)], text=True)
records = {}
for line in accounting.splitlines():
    values = line.split('|')
    if values[0] not in jobs:
        continue
    record = dict(zip(fields, values))
    assert record['State'] == 'COMPLETED' and record['ExitCode'] == '0:0', record
    assert record['Account'] == 'proj-sai-hpc-software', record
    assert record['JobIDRaw'] not in records
    records[record['JobIDRaw']] = record
assert len(records) == len(jobs) == 12
for row in rows:
    row['build_accounting'] = records[row['build_job']]
    row['science_accounting'] = records[row['science_job']]

preliminary = []
for previous in config.get('previous_operations', []):
    previous = Path(previous)
    assert previous.parent == project / 'operations'
    old = read(previous / 'config.json')
    base = 'preliminary/' + old['commit'][:12]
    for path in sorted(previous.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.py', '.log'):
            retain(path, base + '/operations/' + path.name)
    for path in sorted(previous.glob('fortran-regression*/result.log')):
        retain(path, base + '/operations/' + str(path.relative_to(previous)))
    for path in sorted(previous.glob('fortran-regression*/tests/*.py')):
        retain(path, base + '/operations/' + str(path.relative_to(previous)))
    prior_cases = {case['name']: case for case in old['cases']}
    for alternate in previous.glob('config-original-*.json'):
        prior_cases.update({case['name']: case for case in read(alternate)['cases']})
    for case in prior_cases.values():
        run_id = 'cp2k-aux-20261106-' + old['commit'][:12] + '-' + case['name'] + '-cold'
        run = project / 'runs' / run_id
        if not (run / 'job.id').is_file():
            continue
        job = (run / 'job.id').read_text().strip()
        prior_accounting = subprocess.check_output(['sacct', '-X', '-nP', '-j', job,
                                                    '-o', ','.join(fields)], text=True)
        preliminary.append(dict(run_id=run_id, accounting=prior_accounting))
        for name in ('request.json', 'job.sbatch', 'job.id'):
            retain(run / name, base + '/builds/' + case['name'] + '/' + name)
        for path in sorted((run / 'results').rglob('*')):
            if path.is_file():
                retain(path, base + '/builds/' + case['name'] + '/' + str(path.relative_to(run)))
    for path in sorted(Path(old['controller']).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            retain(path, base + '/controller/' + str(path.relative_to(old['controller'])))

summary = dict(schema=1, observed_at=datetime.now(timezone.utc).isoformat(),
               controller_commit=config['commit'], controller=str(control),
               recipe_sha256=recipe_fingerprint('cp2k', control), config=config,
               completed=True, rows=rows, cold_warm_comparisons=pairs, accounting=accounting,
               preliminary_builds=preliminary,
               comparison_count=sum(map(len, pairs.values())), calculation_count=84,
               rank_comparison_count=42, energy_tolerance_ha=1e-6, force_tolerance_ha_bohr=1e-5,
               timing_scope='Descriptive build timings; nodes and filesystem conditions may differ.')
report = operation / 'qualification.json'
report.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
for path in sorted(control.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        retain(path, 'controller/' + str(path.relative_to(control)))
for path in sorted(operation.iterdir()):
    if path.is_file() and (path.suffix in ('.py', '.log') or
                          (path.suffix == '.json' and path.name not in ('archive.json', 'file-hashes.json'))):
        retain(path, 'operations/' + path.name)

archive = operation / 'evidence.tar.gz'
inventory = {name: checksum(path) for name, path in sorted(files.items())}
index = operation / 'file-hashes.json'
index.write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for name, path in sorted(files.items()):
        assert checksum(path) == inventory[name], path
        tar.add(path, arcname=name, recursive=False)
    tar.add(index, arcname='file-hashes.json', recursive=False)
archive_record = dict(schema=1, archive_sha256=checksum(archive), archive_bytes=archive.stat().st_size,
                      raw_file_count=len(inventory), raw_hash_index_sha256=checksum(index))
(operation / 'archive.json').write_text(json.dumps(archive_record, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(complete=True, comparisons=summary['comparison_count'], **archive_record)), flush=True)
