"""Advance existing cold/warm qualification jobs without blocking on Slurm."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

operation = Path(__file__).resolve().parent
config = json.loads((operation / 'config.json').read_text())
project, control = Path(config['project']), Path(config['controller'])
assert operation == Path(config['operation'])
sys.dont_write_bytecode = True
sys.path.insert(0, str(control))
os.environ['SAI_SOFTWARE_ROOT'] = str(project)
from source_cache import checksum
from input_archive_cache import stage
from software_controller import recipe_fingerprint


def read(path):
    return json.loads(path.read_text())


def call(name, *args):
    command = [sys.executable, '-B', str(control / name), *map(str, args)]
    if name == 'cp2k_acceptance.py' and args[0] == 'monitor':
        command = [sys.executable, '-B', str(operation / 'resume_science.py'), *map(str, args[1:])]
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')
    with (operation / (stamp + '-' + name + '.log')).open('w') as output:
        output.write(json.dumps(command) + '\n')
        output.flush()
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(name + ' ' + str(args[:2]) + ' exited ' + str(result.returncode))


def state(job):
    text = subprocess.check_output(['sacct','-X','-nP','-j',job,
        '-o','JobIDRaw,State,ExitCode,Elapsed,NodeList,Account,Partition'],text=True)
    records = [line.split('|') for line in text.splitlines() if line.split('|')[0] == job]
    if not records:
        return dict(job=job,state='ACCOUNTING_PENDING')
    assert len(records)==1
    row=records[0]
    assert row[5]=='proj-sai-hpc-software'
    return dict(job=job,state=row[1],exit_code=row[2],elapsed=row[3],nodes=row[4],account=row[5],partition=row[6])


def advance(case, phase):
    run_id='cp2k-aux-20261106-'+config['commit'][:12]+'-'+case['name']+'-'+phase
    run=project/'runs'/run_id
    version=case[phase+'_version']
    if not (run/'job.id').exists():
        old=project/'runs'/('42139209945-1-'+case['track']+'-'+case['target']+'-2026-11-06-'+case['sha'][:12])
        source=old/'input/cp2k-updates'
        assert source.is_dir()
        destination=run/'input/cp2k-updates'
        destination.mkdir(parents=True,exist_ok=True)
        archives=sorted(p for p in source.iterdir() if p.name.endswith(('.tar.gz','.tar.xz','.tar.bz2')))
        assert len(archives)==6
        for archive in archives:
            assert stage(project,destination,archive.name,checksum(archive))
        call('software_controller.py','submit','cp2k',run_id,case['sha'],version,case['target'],
             '--track',case['track'],'--source-ref',case['ref'],'--overlay-mb','16384','--minutes','90')
    request=read(run/'request.json')
    assert request['controller']==str(control) and request['recipe_sha256']==recipe_fingerprint('cp2k',control)
    build=state((run/'job.id').read_text().strip())
    row=dict(run_id=run_id,version=version,identity=request['identity'],build=build)
    if build['state'] in ('PENDING','RUNNING','COMPLETING','ACCOUNTING_PENDING'):
        return row
    assert (build['state'],build['exit_code'])==('COMPLETED','0:0'),build
    status=run/'results/status.json'
    if not status.exists() or not read(status).get('verified'):
        call('software_controller.py','monitor',run_id,'--timeout','5')
    receipt=read(run/'results/auxiliary-cache.json')
    assert receipt['enabled'] and receipt['hit']==(phase=='warm'),receipt
    row['cache']={k:v for k,v in receipt.items() if k!='contract'}
    science_id=run_id+'-science'
    science=project/'runtime-tests'/science_id
    if not (science/'job.id').exists():
        call('cp2k_acceptance.py','submit',science_id,version,case['target'],'--build-run-id',run_id)
    scientific=state((science/'job.id').read_text().strip())
    row['science']=scientific
    if scientific['state'] in ('PENDING','RUNNING','COMPLETING','ACCOUNTING_PENDING'):
        return row
    assert (scientific['state'],scientific['exit_code'])==('COMPLETED','0:0'),scientific
    scientific_status=science/'results/status.json'
    if not scientific_status.exists() or not read(scientific_status).get('verified'):
        call('cp2k_acceptance.py','monitor',science_id,'--timeout','5')
    artifact=Path((run/'artifact.path').read_text().strip())
    manifest=read(artifact.with_suffix('.json'))
    if not manifest.get('published') or (phase=='cold' and not (run/'results/auxiliary-cache-published.json').exists()):
        call('software_controller.py','publish',run_id)
    manifest=read(artifact.with_suffix('.json'))
    assert manifest['published'] and manifest['verified'] and manifest['cp2k_science']['verified']
    row.update(accepted=True,artifact=str(artifact),artifact_sha256=manifest['sha256'])
    return row


rows=[]
for case in config['cases']:
    for phase in ('cold','warm'):
        try:
            row=advance(case,phase)
            rows.append(row)
            if not row.get('accepted'):break
        except Exception as exc:
            rows.append(dict(case=case['name'],phase=phase,error=type(exc).__name__+': '+str(exc)))
            break
result=dict(observed_at=datetime.now(timezone.utc).isoformat(),commit=config['commit'],
            recipe_sha256=recipe_fingerprint('cp2k',control),rows=rows)
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')
(operation/(stamp+'-observation.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(operation/'latest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
