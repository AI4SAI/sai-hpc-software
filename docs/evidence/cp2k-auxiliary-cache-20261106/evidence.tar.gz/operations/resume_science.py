"""Resume frozen science verification with only the retired-job monitor repair.

Keep the on-disk controller and its original verifier intact. Assert that the
staged repair changes only monitor(), then execute that function with the
original module globals. All source/launcher hashes and numerical gates remain
the frozen controller's. The collector independently repeats its verify_evidence.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import sys

operation = Path(__file__).resolve().parent
config = json.loads((operation / 'config.json').read_text())
os.environ['SAI_SOFTWARE_ROOT'] = config['project']
sys.dont_write_bytecode = True
sys.path.insert(0, config['controller'])
import cp2k_acceptance as original

frozen = Path(original.__file__)
patched = operation / 'cp2k_acceptance-retired-job.py'
trees = [ast.parse(path.read_text()) for path in (frozen, patched)]
monitors = []
for tree in trees:
    matches = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'monitor']
    assert len(matches) == 1
    monitors.append(matches[0])
    tree.body.remove(matches[0])
assert ast.dump(trees[0], include_attributes=False) == ast.dump(trees[1], include_attributes=False)
print(json.dumps(dict(operation='resume-science-with-retired-job-monitor',
                     original=str(frozen), original_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),
                     monitor_source=str(patched), monitor_source_sha256=hashlib.sha256(patched.read_bytes()).hexdigest(),
                     preserved='original controller, artifact checks and scientific verifier')), flush=True)
exec(compile(ast.Module(body=[monitors[1]], type_ignores=[]), str(patched), 'exec'), vars(original))
parser = argparse.ArgumentParser()
parser.add_argument('run_id')
parser.add_argument('--timeout', type=int, default=60)
parser.add_argument('--interval', type=int, default=15)
raise SystemExit(original.monitor(parser.parse_args()) or 0)
