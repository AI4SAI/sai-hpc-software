from pathlib import Path
import sys,json,subprocess,hashlib
root=Path('/org/org-open-sai/proj-sai-hpc-software')
snapshot=root/'controller/beta/645df69fb0343fb666f5d93f9d13759619b7ad70/41583854521-1-abacus'
sys.path.insert(0,str(snapshot/'controller'))
import beta_check
base=root/'diagnostics/build-failure-20261103'
base.mkdir(exist_ok=True)
p=base/'gpu_probe.py'
probe='import ctypes, json, os, socket, subprocess\nresult = {"node": socket.gethostname(), "job": os.environ.get("SLURM_JOB_ID"),\n          "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),\n          "slurm_job_gpus": os.environ.get("SLURM_JOB_GPUS")}\nr = subprocess.run(["nvidia-smi", "--query-gpu=index,uuid,ecc.errors.uncorrected.volatile.total,ecc.errors.uncorrected.aggregate.total", "--format=csv"], text=True, capture_output=True)\nresult["nvidia_smi"] = dict(returncode=r.returncode, stdout=r.stdout, stderr=r.stderr)\ntry:\n    runtime = ctypes.CDLL("/opt/devtools/nvidia/cuda-12.9.1/lib64/libcudart.so.12")\n    runtime.cudaGetErrorString.argtypes = [ctypes.c_int]\n    runtime.cudaGetErrorString.restype = ctypes.c_char_p\n    def error(code):\n        return dict(code=code, message=runtime.cudaGetErrorString(code).decode())\n    count = ctypes.c_int()\n    result["device_count_status"] = error(runtime.cudaGetDeviceCount(ctypes.byref(count)))\n    result["device_count"] = count.value\n    result["devices"] = []\n    for i in range(count.value):\n        row = dict(ordinal=i, set_device=error(runtime.cudaSetDevice(i)))\n        if row["set_device"]["code"] == 0:\n            row["context_init"] = error(runtime.cudaFree(ctypes.c_void_p()))\n        result["devices"].append(row)\nexcept Exception as e:\n    result["error"] = repr(e)\nprint(json.dumps(result, indent=2))\n'
if p.exists(): assert p.read_text()==probe
else: p.write_text(probe)
bundle=root/'operations/daily-beta/41583854521-1-abacus-645df69fb034/bundle'
for name,selection in [('suspect-n09','#SBATCH --nodelist=8v100v0n09'),('control-other','#SBATCH --exclude=8v100v0n09')]:
 directory=base/name
 if directory.exists():
  print('existing',directory);continue
 request=beta_check.prepare('abacus','8V100V0',bundle,directory,snapshot/'fixtures')
 script=beta_check.render('abacus','8V100V0',bundle,directory)
 script=script.replace('#SBATCH --time=30','#SBATCH --time=10\n'+selection)
 script=script.replace('cd case\n','python3 -B '+str(p)+' > gpu-probe.json\ncd case\n')
 (directory/'job.sbatch').write_text(script)
 subprocess.run(['bash','-n',str(directory/'job.sbatch')],check=True)
 subprocess.run(['sbatch','--test-only',str(directory/'job.sbatch')],check=True,capture_output=True)
 job=subprocess.check_output(['sbatch','--hold','--parsable',str(directory/'job.sbatch')],text=True).strip().split(';')[0]
 assert job.isdigit()
 record=dict(job=job,name=name,path=str(directory),selection=selection,script_sha256=hashlib.sha256(script.encode()).hexdigest(),request=request)
 (directory/'diagnostic-submission.json').write_text(json.dumps(record,indent=2))
 subprocess.run(['scontrol','release',job],check=True)
 print(json.dumps(dict(job=job,name=name,path=str(directory))))
