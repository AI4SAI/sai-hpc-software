import ctypes, json, os, socket, subprocess
result = {"node": socket.gethostname(), "job": os.environ.get("SLURM_JOB_ID"),
          "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
          "slurm_job_gpus": os.environ.get("SLURM_JOB_GPUS")}
r = subprocess.run(["nvidia-smi", "--query-gpu=index,uuid,ecc.errors.uncorrected.volatile.total,ecc.errors.uncorrected.aggregate.total", "--format=csv"], text=True, capture_output=True)
result["nvidia_smi"] = dict(returncode=r.returncode, stdout=r.stdout, stderr=r.stderr)
try:
    runtime = ctypes.CDLL("/opt/devtools/nvidia/cuda-12.9.1/lib64/libcudart.so.12")
    runtime.cudaGetErrorString.argtypes = [ctypes.c_int]
    runtime.cudaGetErrorString.restype = ctypes.c_char_p
    def error(code):
        return dict(code=code, message=runtime.cudaGetErrorString(code).decode())
    count = ctypes.c_int()
    result["device_count_status"] = error(runtime.cudaGetDeviceCount(ctypes.byref(count)))
    result["device_count"] = count.value
    result["devices"] = []
    for i in range(count.value):
        row = dict(ordinal=i, set_device=error(runtime.cudaSetDevice(i)))
        if row["set_device"]["code"] == 0:
            row["context_init"] = error(runtime.cudaFree(ctypes.c_void_p()))
        result["devices"].append(row)
except Exception as e:
    result["error"] = repr(e)
print(json.dumps(result, indent=2))
