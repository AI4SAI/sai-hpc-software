from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/org/org-open-sai/proj-sai-hpc-software/experimental/deepmd-lammps')
EXP = ROOT / 'generator-benchmarks/pr5308-20261108-v1'
SCI = ROOT / 'runtime-tests/pr5308-20261108-v1-science'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, record):
    with path.open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')


request = read(EXP / 'request.json')
validation = read(SCI / 'validation.json')
science_request = read(SCI / 'request.json')
assert validation['passed'] and validation['cases'] == 28
for name, expected in validation['process_files'].items():
    assert digest(SCI / name) == expected, name
jobs = dict(build=(EXP / 'job.id').read_text().strip(), science=(SCI / 'job.id').read_text().strip())
for label, job in jobs.items():
    status = subprocess.check_output(['sacct', '-X', '-n', '-P', '-j', job,
                                     '-o', 'JobIDRaw,State,ExitCode'], text=True)
    assert status.strip().rstrip('|').split('|') == [job, 'COMPLETED', '0:0'], status
    accounting = subprocess.check_output(['sacct', '-j', job, '-P',
        '-o', 'JobID,State,ExitCode,Start,End,Elapsed,ElapsedRaw,TotalCPU,AllocCPUS,MaxRSS,NodeList,Partition,Account,WorkDir'], text=True)
    (EXP / (label + '-accounting.txt')).write_text(accounting)

artifacts = {}
for row in request['variants']:
    image = Path(row['run']) / 'candidate.sif'
    sha = digest(image)
    assert sha == science_request['variants'][row['label']]['image_sha256']
    artifacts[row['label']] = dict(path=str(image), sha256=sha, bytes=image.stat().st_size,
                                   source_sha=row['delivery']['identity']['source_sha'])
write(EXP / 'artifacts.json', artifacts)

lines = (EXP / ('slurm-' + jobs['build'] + '.log')).read_text().splitlines()
full_flow = {}
for label in ('pr5308', 'base'):
    begin = datetime.datetime.fromisoformat(lines[lines.index('START_' + label.upper()) + 1])
    end = datetime.datetime.fromisoformat(lines[lines.index('FINISHED_' + label.upper()) + 1])
    full_flow[label] = dict(start=begin.isoformat(), end=end.isoformat(), seconds=(end-begin).total_seconds())
comparison = read(EXP / 'comparison.json')
topology = read(EXP / 'allocated-cpu-topology.json')
summary = dict(upstream=comparison['upstream'], jobs=jobs, build_node=topology['node'],
    physical_cores=topology['physical_cores'], logical_cpus=topology['logical_cpus'], workers=24,
    compiler_commands=comparison['compiler_commands'], host_only_commands=comparison['host_only_commands'],
    compiler_inputs_match_except_host_only_and_install_prefix=True,
    package_count={k: len(v['lammps']['packages']) for k, v in validation['features'].items()},
    styles_identical=validation['features']['base']['lammps']['styles'] == validation['features']['pr5308']['lammps']['styles'],
    numerical_cases=validation['cases'], numerical_passed=True, full_flow=full_flow,
    variants={k: dict(configure_seconds=v['phases']['configure']['elapsed_seconds'],
                     build_seconds=v['phases']['build']['elapsed_seconds'],
                     install_seconds=v['phases']['install']['elapsed_seconds'],
                     build_cpu_seconds=v['phases']['build']['cpu_seconds'],
                     average_compiler_cpu_cores=v['phases']['build']['average_cpu_cores'],
                     sampled_compiler_pss_peak_gib=v['sampled_process_pss_peak_gib'])
              for k, v in comparison['variants'].items()},
    build_time_reduction_percent=comparison['build_time_reduction_percent'],
    build_speedup=comparison['build_speedup'],
    full_flow_time_reduction_percent=100 * (1 - full_flow['pr5308']['seconds'] / full_flow['base']['seconds']),
    scope='one clean pair, PR first, OS cache not flushed; one-node scientific regression, not production publication',
    artifacts=artifacts)
write(EXP / 'summary.json', summary)

files = {}
for name in ('request.json', 'job.sbatch', 'job.id', 'submission-intent.json', 'slurm-' + jobs['build'] + '.log',
             'comparison.json', 'upstream.diff', 'allocated-cpu-topology.json', 'lscpu.txt', 'allocation.txt',
             'nvidia-smi.txt', 'compile-input-preflight.json', 'monitor.jsonl', 'artifacts.json',
             'build-accounting.txt', 'science-accounting.txt', 'summary.json'):
    files['experiment/' + name] = EXP / name
control = Path(request['controller'])
for name, expected in request['controller_files'].items():
    assert digest(control / name) == expected, name
    if name.startswith('benchmark/'):
        files['controller/' + name] = control / name
files['controller/snapshot.json'] = control.parent / 'snapshot.json'
for row in request['variants']:
    run = Path(row['run'])
    for name in ('request.json', 'job.sbatch', 'job.id'):
        files['build/' + row['label'] + '/' + name] = run / name
    for directory in ('results', 'runtime'):
        for path in (run / directory).rglob('*'):
            if not path.is_file():
                continue
            relative = str(path.relative_to(run))
            if directory == 'runtime' and not (
                    path.name.startswith('cmake-') or path.name in (
                        'CMakeCache.txt', 'compile_commands.json', 'source.json', 'source-local.diff', 'host-only.json')
                    or 'build-metadata/' in relative or 'cmake-response-files/' in relative):
                continue
            files['build/' + row['label'] + '/' + relative] = path
for name in ('request.json', 'request.sha256', 'job.sbatch', 'job.id', 'reference.json', 'submission-intent.json',
             'validation.json', 'slurm-' + jobs['science'] + '.log', 'modules.txt', 'allocation.txt', 'nodes.txt'):
    files['science/' + name] = SCI / name
for directory in ('control', 'helpers', 'results'):
    for path in (SCI / directory).rglob('*'):
        if not path.is_file():
            continue
        relative = str(path.relative_to(SCI))
        if directory != 'results' or path.name in ('stdout.txt', 'process.json', 'features.json', 'result.dump', 'COLVAR', 'log.lammps') or '/ranks/' in relative:
            files['science/' + relative] = path
files['experiment/collect.py'] = Path(__file__)
manifest = {name: dict(source=str(path), bytes=path.stat().st_size, sha256=digest(path))
            for name, path in sorted(files.items())}
archive = EXP / 'evidence.raw.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for name, path in sorted(files.items()):
        info = tar.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        with path.open('rb') as stream:
            tar.addfile(info, stream)
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    info = tarfile.TarInfo('manifest.json')
    info.size = len(payload)
    tar.addfile(info, io.BytesIO(payload))
print(json.dumps(dict(summary=summary, archive=dict(path=str(archive), sha256=digest(archive),
                                                  bytes=archive.stat().st_size, files=len(files))), indent=2))
