#!/usr/bin/env python3
"""Isolated paired-stack candidate builds; never changes production modules.

Successful compilation creates an unpublished candidate. This experimental
controller deliberately has no implicit publish operation: scientific and
performance acceptance is a separate, required lifecycle stage.
"""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import time
from md_tracking import fingerprint, identify_track_pair, TARGETS as MD_TARGETS
from remote_controller import TARGETS, container_command, safe_name, safe_sha, site_app_binds, project_batch_directives, private_scratch
from source_cache import checksum
from cp2k_image_driver import wrap_command as image_driver_command, module_load_command

PROJECT = Path(os.environ.get('SAI_SOFTWARE_ROOT', Path.home() / 'sai-hpc-software')).resolve()
ROOT = PROJECT / 'experimental/deepmd-lammps'
CONTROL = Path(__file__).resolve().parent
BUILD_STAGES = {
    'deepmd': dict(qos='flood-1o2gpu', gpus=1, minutes=180, max_minutes=240),
    'lammps': dict(qos='rush-gpu', gpus=4, minutes=330, max_minutes=330),
}


def join(argv):
    return shlex.join(list(map(str, argv)))


def run(argv, **kwargs):
    return subprocess.run(list(map(str, argv)), check=True, text=True, **kwargs)


def task(run_id):
    path = ROOT / 'runs' / safe_name(run_id)
    if path.resolve() != path:
        raise ValueError('symlinked task root')
    return path


def validate_pair(request):
    if (not isinstance(request, dict) or set(request) != {'schema', 'plan', 'recipe_sha256', 'identities'}
            or type(request['schema']) is not int or request['schema'] != 2):
        raise ValueError('expected schema-2 MD delivery; legacy pairs must be resolved again')
    from release_contract import validate_identity
    if not isinstance(request['identities'], dict) or set(request['identities']) != {'deepmd-kit', 'lammps'}:
        raise ValueError('missing paired identities')
    schemas = {validate_identity(item)['schema'] for item in request['identities'].values()}
    if len(schemas) != 1:
        raise ValueError('mixed installation layout schemas in paired delivery')
    identities = identify_track_pair(request['plan'], request['recipe_sha256'],
                                     layout_schema=schemas.pop())
    if json.dumps(request['identities'], sort_keys=True) != json.dumps(identities, sort_keys=True):
        raise ValueError('MD identities differ from the locked sources, recipe or partition')
    return request


def artifact_path(root, request, run_id):
    """One paired SIF path for build, candidate sidecar and runtime gates."""
    validate_pair(request)
    root = Path(root)
    artifact = (root / 'containers/software/deepmd-lammps' / request['plan']['selection_sha256'] /
                request['recipe_sha256'] / request['identities']['lammps']['partition'] /
                (safe_name(run_id) + '.sif'))
    if not root.is_absolute() or root.resolve() != root or artifact.resolve() != artifact:
        raise ValueError('MD artifact path must be absolute and contain no symlinks')
    return artifact



def validate_runtime_image(image, delivery):
    """Bind runtime execution to the verified build's bytes and paired identity."""
    image = Path(image)
    delivery = validate_pair(delivery)
    if (image != artifact_path(ROOT, delivery, image.stem)
            or image.is_symlink() or image.resolve() != image):
        raise ValueError('MD image differs from its canonical paired delivery path')
    sidecar = image.with_suffix('.json')
    if sidecar.is_symlink() or sidecar.resolve() != sidecar:
        raise ValueError('untrusted MD image sidecar')
    status = json.loads(sidecar.read_text())
    if (status.get('build_verified') is not True or status.get('state') != 'COMPLETED'
            or status.get('exit_code') != '0:0' or status.get('artifact') != str(image)
            or status.get('delivery') != delivery
            or status.get('artifact_sha256') != checksum(image)):
        raise ValueError('MD runtime image or build identity changed')
    return image

def render(request, run_id, jobs=None, minutes=None, overlay_mb=32768,
           stage='all', dependency=None):
    validate_pair(request)
    plan = request['plan']
    target = TARGETS[plan['target']]
    if stage not in ('all', 'deepmd', 'lammps'):
        raise ValueError('unknown MD build stage')
    resources = BUILD_STAGES['lammps' if stage == 'all' else stage]
    max_jobs = min(6, target.get('build_jobs', 6)) * resources['gpus']
    if jobs is None:
        jobs = max_jobs
    if minutes is None:
        minutes = resources['minutes']
    if not 1 <= jobs <= max_jobs or not 1 <= minutes <= resources['max_minutes']:
        raise ValueError('MD build resources outside experimental bounds')
    if not 8192 <= overlay_mb <= 65536:
        raise ValueError('overlay capacity outside policy')
    if dependency is not None and (stage != 'lammps' or not str(dependency).isdigit()):
        raise ValueError('invalid staged build dependency')
    r = task(run_id)
    image = PROJECT / 'containers/base/minimal-v1.sif'
    overlay = r / 'work.ext3'
    result = r / 'candidate.sif'
    artifact = artifact_path(ROOT, request, run_id)
    entry_phase = {'all': 'build', 'deepmd': 'build-deepmd', 'lammps': 'build-lammps'}[stage]
    args = ['/usr/bin/bash', '/control/md_container_entry.sh', entry_phase,
            json.dumps(request, sort_keys=True, separators=(',', ':'))]
    def container(phase, final=False):
        command = args.copy()
        command[2] = phase
        sources = [(ROOT / 'cache/repositories' / name, '/input/' + name) for name in plan['sources']]
        argv = container_command(result if final else image, command, overlay=None if final else overlay,
                                 control=CONTROL, jobs=jobs, gpu=True,
                                 runtime=r / 'runtime' if final else None,
                                 extra_binds=[*site_app_binds('lammps'), *(sources if not final else [])])
        # Reuse the checksum-pinned driver already qualified for CP2K. Its
        # independent copy in ROOT/cache/tools keeps the MD run-path contract.
        if final:
            # A read-only SIF needs no fake ownership. Fakeroot injects its
            # private libfakeroot.so into ldd and contaminates native auditing.
            return [argument for argument in argv if argument != '--fakeroot']
        return image_driver_command(ROOT, r, CONTROL, argv)
    emit = image_driver_command(ROOT, r, CONTROL, container_command(
        image, ['/usr/bin/cat', '/workspace/final.squashfs'],
        overlay=str(overlay) + ':ro', jobs=jobs))
    lines = ['#!/usr/bin/env bash', f'#SBATCH --job-name=md-{safe_name(run_id)}', '#SBATCH --dependency=singleton',
             f'#SBATCH --partition={target["partition"]}', f'#SBATCH --qos={resources["qos"]}',
             '#SBATCH --nodes=1', '#SBATCH --ntasks=1', f'#SBATCH --gpus-per-node={resources["gpus"]}',
             f'#SBATCH --time={minutes}', f'#SBATCH --output={r}/results/slurm-%j.log',
             '#SBATCH --export=NIL', *project_batch_directives(PROJECT, r),
             'set -eo pipefail', 'export PATH=/usr/bin:/bin',
             'export LD_LIBRARY_PATH="" LD_PRELOAD=""', 'source /etc/profile.d/lmod.sh',
             module_load_command(), 'set -u', 'umask 077',
             f'export TMPDIR={shlex.quote(str(r / "runtime"))}',
             f'export APPTAINER_TMPDIR={shlex.quote(str(r / "runtime"))}',
             f'export APPTAINER_CACHEDIR={shlex.quote(str(r / "apptainer-cache"))}',
             'export APPTAINERENV_SAI_MD_ALLOCATED_JOB="$SLURM_JOB_ID"',
             'export APPTAINERENV_SAI_MD_ALLOCATED_NODE="$(hostname)"',
             'unset APPTAINER_BIND APPTAINER_BINDPATH SINGULARITY_BIND SINGULARITY_BINDPATH']
    if dependency is not None:
        lines[2] = f'#SBATCH --dependency=afterok:{dependency},singleton'
        lines.insert(3, '#SBATCH --kill-on-invalid-dep=yes')
    lines += [f'[[ ${{SLURM_CPUS_ON_NODE:?missing CPU allocation}} -ge {jobs} ]]',
              f'echo MD_BUILD_RESOURCES stage={stage} gpus={resources["gpus"]} jobs={jobs} allocated_cpus="$SLURM_CPUS_ON_NODE"',
              join(['test', '-s', image])]
    lines.append(join(['/usr/bin/python3', '-c',
                       f'import sys; sys.path.insert(0, {str(CONTROL)!r}); '
                       f'from remote_controller import require_capacity; require_capacity({str(ROOT)!r}, {overlay_mb})']))
    if stage in ('all', 'deepmd'):
        lines += [join(['test', '!', '-e', overlay]),
                  join(['apptainer', 'overlay', 'create', '--fakeroot', '--sparse', '--size', str(overlay_mb), overlay])]
    else:
        lines += [join(['test', '-e', overlay])]
    lines.append(join(container(entry_phase)))
    if stage == 'deepmd':
        lines.append('echo MD_DEEPMD_STAGE_BUILT')
    else:
        lines += [join(container('export')),
                  join(emit) + ' > ' + shlex.quote(str(r / 'final.squashfs')),
                  join(['apptainer', 'sif', 'new', result]),
                  join(['apptainer', 'sif', 'add', '--datatype', '4', '--partfs', '1', '--parttype', '2',
                            '--partarch', '2', '--groupid', '1', result, r / 'final.squashfs']),
                  join(container('verify', final=True)),
                  join(['mkdir', '-p', artifact.parent]), join(['test', '!', '-e', artifact]),
                  join(['chmod', '0444', result]), join(['mv', result, artifact]),
                  f"printf '%s\\n' {shlex.quote(str(artifact))} > {shlex.quote(str(r / 'artifact.path'))}",
                  'echo MD_CANDIDATE_BUILT_NOT_PUBLISHED']
    # Keep failed overlays for diagnosis. No source/install tree is ever on host.
    return '\n'.join(lines) + '\n'


def submit_probe(args):
    """One GPU, five minutes, no source checkout or production mutations."""
    if args.target not in MD_TARGETS:
        raise ValueError('unvalidated MD probe target')
    from remote_controller import require_capacity
    require_capacity(ROOT, 8192 if args.op == 'baseline' else 1024)
    r = task(args.run_id)
    if (r / 'job.id').exists():
        raise ValueError('probe already submitted')
    for part in ('results', 'runtime', 'apptainer-cache'):
        (r / part).mkdir(parents=True, exist_ok=True)
    for part in ('runtime', 'apptainer-cache'):
        private_scratch(r / part)
    target = TARGETS[args.target]
    baseline = args.op == 'baseline'
    probe_script = {'baseline': 'md_baseline.sh', 'probe': 'md_native_probe.sh',
                    'import-probe': 'md_import_probe.sh', 'conversion-probe': 'md_import_probe.sh'}[args.op]
    entry = ['/usr/bin/bash', '/control/' + probe_script, args.target]
    binds = list(site_app_binds('lammps'))
    if baseline or args.op == 'conversion-probe':
        entry.append(safe_sha(args.sha))
        repository = ROOT / 'cache/repositories/deepmd-kit'
        run(['git', '--git-dir', repository, 'cat-file', '-e', args.sha + '^{commit}'])
        binds.append((repository, '/input/deepmd-kit'))
    command = container_command(PROJECT / 'containers/base/minimal-v1.sif', entry, overlay=r / 'probe.ext3',
        control=CONTROL, jobs=1, gpu=True, extra_binds=binds)
    lines = ['#!/usr/bin/env bash', f'#SBATCH --job-name={args.run_id}',
             f'#SBATCH --partition={target["partition"]}', f'#SBATCH --qos={target["qos"]}',
             '#SBATCH --nodes=1', '#SBATCH --ntasks=1', '#SBATCH --gpus-per-node=1', '#SBATCH --time=' + ('10' if baseline else '5'),
             f'#SBATCH --output={r}/results/slurm-%j.log', '#SBATCH --export=NIL',
             *project_batch_directives(PROJECT, r),
             'set -eo pipefail', 'export PATH=/usr/bin:/bin LD_LIBRARY_PATH="" LD_PRELOAD=""',
             'source /etc/profile.d/lmod.sh', module_load_command(), 'set -u',
             f'export TMPDIR={shlex.quote(str(r / "runtime"))} APPTAINER_TMPDIR={shlex.quote(str(r / "runtime"))}',
             f'export APPTAINER_CACHEDIR={shlex.quote(str(r / "apptainer-cache"))}',
             'export APPTAINERENV_SAI_MD_ALLOCATED_JOB="$SLURM_JOB_ID"',
             'export APPTAINERENV_SAI_MD_ALLOCATED_NODE="$(hostname)"',
             'unset APPTAINER_BIND APPTAINER_BINDPATH SINGULARITY_BIND SINGULARITY_BINDPATH',
             join(['test', '!', '-e', r / 'probe.ext3']),
             join(['apptainer', 'overlay', 'create', '--fakeroot', '--sparse', '--size', '8192' if baseline else '1024', r / 'probe.ext3']),
             join(command)]
    script = r / 'job.sbatch'
    script.write_text('\n'.join(lines) + '\n')
    run(['bash', '-n', script])
    try:
        submitted = run(['sbatch', '--parsable', script], capture_output=True, cwd=r)
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or '').strip()
        raise RuntimeError('MD Slurm submission failed' + (': ' + detail if detail else '')) from exc
    job = submitted.stdout.strip().split(';')[0]
    if not job.isdigit():
        raise ValueError('invalid probe job handle')
    (r / 'job.id').write_text(job + '\n')
    (r / 'request.json').write_text(json.dumps({'target': args.target, 'job': job,
        'job_script_sha256': checksum(script), 'recipe_sha256': fingerprint(CONTROL)}) + '\n')
    print(job, flush=True)


def submit(args):
    request = validate_pair(json.loads(Path(args.request).read_text()))
    if request['recipe_sha256'] != fingerprint(CONTROL):
        raise ValueError('uploaded MD recipe differs from runner-locked identities')
    r = task(args.run_id)
    if (r / 'job.id').exists():
        raise ValueError('run already submitted; do not restart a live handle')
    # Slurm can accept an ineligible QoS and leave the job pending forever.
    # Check the partition policy before submitting either dependent stage.
    partition = TARGETS[request['plan']['target']]['partition']
    policy = run(['scontrol', 'show', 'partition', partition, '-o'], capture_output=True).stdout
    allowed = next((field.split('=', 1)[1] for field in policy.split()
                    if field.startswith('AllowQos=')), '')
    required = {resources['qos'] for resources in BUILD_STAGES.values()}
    if allowed != 'ALL' and not required <= set(allowed.split(',')):
        raise ValueError(f'{partition} does not allow both MD stage QoS values: {sorted(required)}')
    from remote_controller import require_capacity
    require_capacity(ROOT, args.overlay_mb)
    for part in ('input', 'results', 'runtime', 'apptainer-cache'):
        (r / part).mkdir(parents=True, exist_ok=True)
    for part in ('runtime', 'apptainer-cache'):
        private_scratch(r / part)
    for name, source in request['plan']['sources'].items():
        run(['git', '--git-dir', ROOT / 'cache/repositories' / name, 'cat-file', '-e', source['sha'] + '^{commit}'])
    record = dict(delivery=request, run_id=args.run_id, controller=str(CONTROL))
    # Separate allocations share one overlay and an explicit afterok edge.
    # LAMMPS needs a longer rush allocation; flood is capped at four hours.
    deepmd_script = r / 'job-deepmd.sbatch'
    script = r / 'job.sbatch'
    for stage, path in (('deepmd', deepmd_script), ('lammps', script)):
        path.write_text(render(request, args.run_id, args.jobs, args.minutes,
                               args.overlay_mb, stage=stage))
        run(['bash', '-n', path])
        # Validate GPU minima, account/QoS permissions and walltime without
        # allocating either stage. No dependency job exists during this check.
        try:
            run(['sbatch', '--test-only', path], capture_output=True, cwd=r)
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or '').strip()
            raise RuntimeError(f'{stage} Slurm resource preflight failed: {detail}') from exc
    deepmd_job = run(['sbatch', '--parsable', deepmd_script], capture_output=True, cwd=r).stdout.strip().split(';')[0]
    if not deepmd_job.isdigit():
        raise ValueError('invalid DeepMD Slurm job handle')
    script.write_text(render(request, args.run_id, args.jobs, args.minutes,
                             args.overlay_mb, stage='lammps', dependency=deepmd_job))
    run(['bash', '-n', script])
    try:
        lammps_job = run(['sbatch', '--parsable', script], capture_output=True, cwd=r).stdout.strip().split(';')[0]
    except subprocess.CalledProcessError as exc:
        record['stage_job_script_sha256'] = {'deepmd': checksum(deepmd_script),
                                             'lammps': checksum(script)}
        record['stage_jobs'] = {'deepmd': deepmd_job}
        (r / 'request.json').write_text(json.dumps(record, sort_keys=True) + '\n')
        raise RuntimeError('LAMMPS stage submission failed after DeepMD job ' + deepmd_job) from exc
    if not lammps_job.isdigit():
        raise ValueError('invalid LAMMPS Slurm job handle')
    record['job_script_sha256'] = checksum(script)
    record['stage_job_script_sha256'] = {'deepmd': checksum(deepmd_script),
                                         'lammps': checksum(script)}
    record['stage_jobs'] = {'deepmd': deepmd_job, 'lammps': lammps_job}
    (r / 'request.json').write_text(json.dumps(record, sort_keys=True) + '\n')
    # Keep job.id as the final stage for existing monitor/acceptance tooling.
    (r / 'job.id').write_text(lammps_job + '\n')
    print(lammps_job, flush=True)


def monitor(args):
    r = task(args.run_id)
    stage = getattr(args, 'stage', 'lammps')
    record = json.loads((r / 'request.json').read_text())
    job = (record['stage_jobs']['deepmd'] if stage == 'deepmd'
           else (r / 'job.id').read_text().strip())
    if not job.isdigit():
        raise ValueError('invalid Slurm job handle')
    deadline = time.monotonic() + args.timeout
    while time.monotonic() < deadline:
        active = run(['squeue', '-h', '-j', job, '-o', '%T|%R'], capture_output=True).stdout.strip()
        if active:
            print(job + ': ' + active, flush=True)
        else:
            rows = run(['sacct', '-X', '-n', '-P', '-j', job, '-o', 'JobIDRaw,State,ExitCode'], capture_output=True).stdout.splitlines()
            row = next((x.split('|') for x in rows if x.split('|')[0] == job), None)
            if row and row[1] not in ('RUNNING', 'PENDING', 'COMPLETING'):
                record = json.loads((r / 'request.json').read_text()) if (r / 'request.json').exists() else {}
                status = {'job': job, 'state': row[1], 'exit_code': row[2], 'build_verified': False,
                          'scientific_verified': False, 'published': False,
                          'stage_jobs': record.get('stage_jobs', {}),
                          'stage_job_script_sha256': record.get('stage_job_script_sha256', {})}
                if stage == 'deepmd':
                    (r / 'results/deepmd-status.json').write_text(json.dumps(status) + '\n')
                    if row[1:3] != ['COMPLETED', '0:0']:
                        return 1
                    if (record['delivery']['recipe_sha256'] != fingerprint(CONTROL)
                            or record['stage_job_script_sha256']['deepmd'] != checksum(r / 'job-deepmd.sbatch')
                            or record['controller'] != str(CONTROL) or record['run_id'] != args.run_id):
                        raise ValueError('DeepMD stage provenance changed')
                    print('DEEPMD_STAGE_COMPLETE: paired candidate still requires LAMMPS', flush=True)
                    return 0
                (r / 'results/status.json').write_text(json.dumps(status) + '\n')
                if row[1:3] != ['COMPLETED', '0:0']:
                    return 1
                request = validate_pair(record['delivery'])
                plan = request['plan']
                artifact = Path((r / 'artifact.path').read_text().strip())
                expected = artifact_path(ROOT, request, args.run_id)
                if (artifact != expected or artifact.resolve() != artifact or artifact.is_symlink()
                        or request['recipe_sha256'] != fingerprint(CONTROL)
                        or record['job_script_sha256'] != checksum(r / 'job.sbatch')
                        or record.get('stage_job_script_sha256', {}).get('deepmd') != checksum(r / 'job-deepmd.sbatch')
                        or record.get('stage_job_script_sha256', {}).get('lammps') != checksum(r / 'job.sbatch')
                        or record['run_id'] != args.run_id or record['controller'] != str(CONTROL)):
                    raise ValueError('candidate provenance changed')
                status['build_verified'] = True
                status.update(artifact=str(artifact), artifact_sha256=checksum(artifact),
                              recipe_sha256=request['recipe_sha256'], sources=plan['sources'],
                              delivery=request, scientific_verified=False, performance_verified=False,
                              native_manifests_packaged=True, native_runtime_verified=False)
                (r / 'results/status.json').write_text(json.dumps(status, sort_keys=True) + '\n')
                artifact.with_suffix('.json').write_text(json.dumps(status, sort_keys=True) + '\n')
                print('CANDIDATE_ONLY: scientific/performance acceptance still required', flush=True)
                return 0
        time.sleep(args.interval)
    raise TimeoutError(f'observation deadline; Slurm job {job} was not cancelled or restarted')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='op', required=True)
    submit_parser = sub.add_parser('submit')
    submit_parser.add_argument('run_id'); submit_parser.add_argument('request')
    submit_parser.add_argument('--jobs', type=int, default=None,
                               help='override both stages; default six build processes per allocated GPU')
    submit_parser.add_argument('--minutes', type=int, default=None,
                               help='override both stages; default DeepMD 180, LAMMPS 330')
    submit_parser.add_argument('--overlay-mb', type=int, default=32768)
    monitor_parser = sub.add_parser('monitor')
    monitor_parser.add_argument('run_id'); monitor_parser.add_argument('--timeout', type=int, default=21600)
    monitor_parser.add_argument('--stage', choices=('deepmd', 'lammps'), default='lammps')
    monitor_parser.add_argument('--interval', type=int, default=30)
    probe_parser = sub.add_parser('probe')
    probe_parser.add_argument('run_id'); probe_parser.add_argument('target', choices=MD_TARGETS)
    baseline_parser = sub.add_parser('baseline')
    baseline_parser.add_argument('run_id'); baseline_parser.add_argument('target', choices=MD_TARGETS); baseline_parser.add_argument('sha')
    import_parser = sub.add_parser('import-probe')
    import_parser.add_argument('run_id'); import_parser.add_argument('target', choices=MD_TARGETS)
    conversion_parser = sub.add_parser('conversion-probe')
    conversion_parser.add_argument('run_id'); conversion_parser.add_argument('target', choices=MD_TARGETS)
    conversion_parser.add_argument('sha')
    args = parser.parse_args()
    raise SystemExit({'submit': submit, 'monitor': monitor, 'probe': submit_probe,
                      'baseline': submit_probe, 'import-probe': submit_probe,
                      'conversion-probe': submit_probe}[args.op](args))
