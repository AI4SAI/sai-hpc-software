from pathlib import Path
import collections
import datetime
import hashlib
import io
import json
import re
import shlex
import subprocess
import sys
import tarfile

ROOT = Path('/org/org-open-sai/proj-sai-hpc-software/experimental/deepmd-lammps')
EXP = ROOT / 'generator-benchmarks/ccache-standard-20261109-v1'
SCI = ROOT / 'runtime-tests/ccache-standard-20261109-v1-science'
SUMMARY_NAME = 'summary.json'
ARCHIVE_NAME = 'evidence.raw.tar.gz'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, record):
    with path.open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')


request = read(EXP / 'request.json')
sys.path.insert(0, request['controller'])
from export_native import SquashfsReader, MANIFEST_PATH
validation = read(SCI / 'validation.json')
science_request = read(SCI / 'request.json')
assert validation['passed'] and validation['cases'] == 28
for name, expected in validation['process_files'].items():
    assert digest(SCI / name) == expected, name
jobs = dict(build=(EXP / 'job.id').read_text().strip(), science=(SCI / 'job.id').read_text().strip())
for label, job in jobs.items():
    status = subprocess.check_output(['sacct', '-X', '-n', '-P', '-j', job,
                                     '-o', 'JobIDRaw,State,ExitCode'], text=True)
    assert status.strip().rstrip('|').split('|') == [job, 'COMPLETED', '0:0'], status
    accounting = subprocess.check_output(['sacct', '-j', job, '-P',
        '-o', 'JobID,State,ExitCode,Start,End,Elapsed,ElapsedRaw,TotalCPU,AllocCPUS,MaxRSS,NodeList,Partition,Account,WorkDir'], text=True)
    (EXP / (label + '-accounting.txt')).write_text(accounting)

variants, artifacts, matches = {}, {}, {}
for row in request['variants']:
    label = row['label']
    run = Path(row['run'])
    image = run / 'candidate.sif'
    sha = digest(image)
    assert sha == science_request['variants'][label]['image_sha256']
    reader = SquashfsReader.from_sif(image)
    install_prefix = row['delivery']['identity']['install_prefix'].lstrip('/')
    manifest, _ = reader.read_manifest(install_prefix + '/' + MANIFEST_PATH)
    compiled = {}
    for item in manifest['files']:
        relative = item['path'].removeprefix(install_prefix + '/')
        if item['kind'] != 'file' or not (relative == 'bin/lmp' or (relative.startswith('lib/') and ('.so' in Path(relative).name or relative.endswith('.a')))):
            continue
        with subprocess.Popen(reader.command([item['path']]), stdout=subprocess.PIPE) as process:
            actual = hashlib.file_digest(process.stdout, 'sha256').hexdigest()
            assert process.wait() == 0
        assert actual == item['sha256'], relative
        compiled[relative] = dict(sha256=actual, bytes=item['size'])
    assert 'bin/lmp' in compiled and any('liblammps.so' in path for path in compiled), compiled
    (run / 'runtime/compiled-files.json').write_text(json.dumps(compiled, indent=2, sort_keys=True) + '\n')
    artifacts[label] = dict(path=str(image), sha256=sha, bytes=image.stat().st_size, compiled_files=compiled,
                            source_sha=row['delivery']['identity']['source_sha'])
    phases = {phase: read(run / 'runtime' / ('cmake-' + phase + '.json'))
              for phase in ('configure', 'build', 'install')}
    assert all(p['returncode'] == 0 for p in phases.values())
    probes = read(run / 'runtime/ccache-probes.json')
    assert len(probes) == 32 and sum(p['hit'] for p in probes) == 16
    stats = read(run / 'runtime/ccache-statistics.json')
    assert stats['internal_error'] == 0, (label, stats)
    assert stats['compile_failed'] == 0 and stats['preprocessor_error'] == 0, (label, stats)
    hits = stats['direct_cache_hit'] + stats['preprocessed_cache_hit']
    commands = read(run / 'runtime/compile_commands.json')
    build_log = (run / ('results/slurm-' + jobs['build'] + '.log')).read_text()
    built = set(re.findall(r'Building (?:CXX|CUDA|C) object (.*)', build_log))
    unbuilt = []
    for command in commands:
        args = shlex.split(command['command'])
        output = str((Path(command['directory']) / args[args.index('-o') + 1]).relative_to('/workspace/lammps-build'))
        if output not in built:
            unbuilt.append(dict(source=command['file'], output=output))
    prefix = row['delivery']['identity']['install_prefix']
    assert prefix not in json.dumps(commands), label
    context_text = (run / 'runtime/ccache-context.json').read_text()
    assert prefix not in context_text and str(run) not in context_text, label
    layout = read(run / 'runtime/ccache-layout.json')
    launcher = read(run / 'runtime/ccache-launcher.json')
    assert launcher['ready'] and launcher['namespace'] == 'standard-layout-v1-' + layout['sha256']
    variants[label] = dict(phases=phases, cache_statistics=stats, include_layout=layout, cache_namespace=launcher['namespace'],
        versioned_install_prefix_in_compiler_commands_or_context=False,
        cache_hits=hits, cache_misses=stats['cache_miss'],
        cache_hit_fraction=hits / (hits + stats['cache_miss']),
        compiler_commands=len(commands),
        logged_compilation_commands=len(built), unbuilt_command_records=unbuilt,
        commands_without_c=len([r for r in commands if '-c' not in shlex.split(r['command'])]),
        cache_probes=len(probes), cache_probe_hits=sum(p['hit'] for p in probes),
        sampled_compiler_pss_peak_gib=phases['build']['sampled_sum_pss_peak_kib'] / 1024**2)
    matches[label] = {name: digest(run / 'runtime' / name) for name in (
        'compile_commands.json', 'ccache-context.json', 'source-local.diff', 'host-only.json')}
assert artifacts['cold']['compiled_files'] == artifacts['warm']['compiled_files']
assert matches['cold'] == matches['warm'], matches
assert variants['cold']['cache_namespace'] == variants['warm']['cache_namespace']
assert variants['cold']['include_layout']['roots'] == variants['warm']['include_layout']['roots']
assert variants['cold']['unbuilt_command_records'] == variants['warm']['unbuilt_command_records']
for variant in variants.values():
    assert variant['logged_compilation_commands'] == (variant['cache_hits'] + variant['cache_misses'] + variant['commands_without_c'])
assert variants['warm']['cache_hits'] > variants['cold']['cache_hits']
assert variants['warm']['cache_misses'] < variants['cold']['cache_misses']
assert variants['cold']['phases']['configure']['argv'] == variants['warm']['phases']['configure']['argv']
assert variants['cold']['phases']['build']['affinity'] == variants['warm']['phases']['build']['affinity']
assert variants['cold']['phases']['build']['node'] == variants['warm']['phases']['build']['node']
assert validation['features']['cold']['lammps']['styles'] == validation['features']['warm']['lammps']['styles']

lines = (EXP / ('slurm-' + jobs['build'] + '.log')).read_text().splitlines()
full_flow = {}
for label in ('cold', 'warm'):
    begin = datetime.datetime.fromisoformat(lines[lines.index('START_' + label.upper()) + 1])
    end = datetime.datetime.fromisoformat(lines[lines.index('FINISHED_' + label.upper()) + 1])
    full_flow[label] = dict(start=begin.isoformat(), end=end.isoformat(), seconds=(end-begin).total_seconds())
cold = variants['cold']['phases']['build']['elapsed_seconds']
warm = variants['warm']['phases']['build']['elapsed_seconds']
cache_files = [p for p in Path(request['cache']).rglob('*') if p.is_file()]
cache_types = collections.Counter()
created = []
for path in cache_files:
    if path.name in ('stats', 'CACHEDIR.TAG'):
        continue
    with path.open('rb') as stream:
        header = stream.read(15)
    # Pinned ccache 4.14.3 --inspect confirms entry-format-1 layout:
    # magic/version, entry type 0=result or 1=manifest, creation time at 7:15.
    assert header[:3] == b'\xcc\xac\x01' and header[3] in (0, 1), str(path)
    cache_types[header[3]] += 1
    created.append(int.from_bytes(header[7:15], 'big'))
assert min(created) >= datetime.datetime.fromisoformat(full_flow['cold']['start']).timestamp()
assert max(created) <= datetime.datetime.fromisoformat(full_flow['warm']['end']).timestamp()
cache_storage = dict(path=request['cache'], files=len(cache_files),
    bytes=sum(p.stat().st_size for p in cache_files),
    allocated_bytes=sum(p.stat().st_blocks * 512 for p in cache_files),
    result_files=cache_types[0], manifest_files=cache_types[1],
    earliest_entry_created_unix=min(created), latest_entry_created_unix=max(created),
    all_entries_created_during_cold_build=max(created) <= datetime.datetime.fromisoformat(full_flow['cold']['end']).timestamp())
summary = dict(source_sha=request['source_sha'], jobs=jobs, artifacts=artifacts,
    build_node=variants['cold']['phases']['build']['node'], workers=24,
    logical_cpus=len(variants['cold']['phases']['build']['affinity']),
    input_hashes=matches['cold'], identical_compiler_commands=True, identical_toolchain_context=True,
    package_count={k: len(v['lammps']['packages']) for k, v in validation['features'].items()},
    styles_identical=True, numerical_cases=28, numerical_passed=True,
    full_flow=full_flow, variants=variants, cache_storage=cache_storage,
    build_time_reduction_percent=100 * (1 - warm/cold), build_speedup=cold/warm,
    full_flow_time_reduction_percent=100 * (1 - full_flow['warm']['seconds'] / full_flow['cold']['seconds']),
    scope='one cold/warm pair, identical pinned PR 5308 source, fresh overlays; OS caches not flushed; one-node numerical regression, not runtime performance or production publication')
write(EXP / SUMMARY_NAME, summary)
files = {}
for name in ('request.json', 'job.sbatch', 'job.id', 'submission-intent.json', 'slurm-' + jobs['build'] + '.log',
             'lscpu.txt', 'allocation.txt', 'build-accounting.txt', 'science-accounting.txt'):
    files['experiment/' + name] = EXP / name
files['experiment/summary.json'] = EXP / SUMMARY_NAME
control = Path(request['controller'])
for name, expected in request['controller_files'].items():
    assert digest(control / name) == expected, name
    files['controller/' + name] = control / name
for row in request['variants']:
    run = Path(row['run'])
    for name in ('request.json', 'job.sbatch', 'job.id'):
        files['build/' + row['label'] + '/' + name] = run / name
    for directory in ('results', 'runtime'):
        for path in (run / directory).rglob('*'):
            if not path.is_file():
                continue
            relative = str(path.relative_to(run))
            if directory == 'runtime' and not (
                    path.name.startswith(('cmake-', 'ccache-')) or path.name in (
                        'CMakeCache.txt', 'compile_commands.json', 'source.json', 'source-local.diff', 'host-only.json', 'compiled-files.json')
                    or 'build-metadata/' in relative or 'cmake-response-files/' in relative):
                continue
            files['build/' + row['label'] + '/' + relative] = path
for name in ('request.json', 'request.sha256', 'job.sbatch', 'job.id', 'reference.json', 'submission-intent.json',
             'validation.json', 'slurm-' + jobs['science'] + '.log', 'modules.txt', 'allocation.txt', 'nodes.txt'):
    files['science/' + name] = SCI / name
for directory in ('control', 'helpers', 'results'):
    for path in (SCI / directory).rglob('*'):
        if not path.is_file():
            continue
        relative = str(path.relative_to(SCI))
        if directory != 'results' or path.name in ('stdout.txt', 'process.json', 'features.json', 'result.dump', 'COLVAR', 'log.lammps') or '/ranks/' in relative:
            files['science/' + relative] = path
files['experiment/collect.py'] = Path(__file__)
manifest = {name: dict(source=str(path), bytes=path.stat().st_size, sha256=digest(path))
            for name, path in sorted(files.items())}
archive = EXP / ARCHIVE_NAME
with tarfile.open(archive, 'x:gz') as tar:
    for name, path in sorted(files.items()):
        info = tar.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        with path.open('rb') as stream:
            tar.addfile(info, stream)
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(payload)
    tar.addfile(info, io.BytesIO(payload))
print(json.dumps(dict(summary=summary, archive=dict(path=str(archive), sha256=digest(archive),
                                                  bytes=archive.stat().st_size, files=len(files))), indent=2))
