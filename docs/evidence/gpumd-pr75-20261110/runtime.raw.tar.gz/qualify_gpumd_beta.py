from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'controller'))
import beta_candidates,daily_beta,sif_modules
from sif_runtime import digest
project=Path('/org/org-open-sai/proj-sai-hpc-software')
rows={}
originals=[]
for directory in sorted((project/'runs').glob('gpumd-42438886026-1-development-*-2026-11-08-1ce6ae2ab2c7')):
    request=json.loads((directory/'request.json').read_text())
    identity=request['identity']
    candidate=beta_candidates.candidate('gpumd',directory,identity)
    rows[identity['partition']]=candidate
    originals.append(dict(run_id=directory.name,request_sha256=digest(directory/'request.json')))
    print('REVALIDATED',identity['partition'],flush=True)
assert set(rows)=={'16V100','4V100','8V100V0'}
snapshot=dict(schema=1,snapshot='20261110',runtime_sha256=digest(root/'controller/sif_runtime.py'),
    applications={'gpumd':dict(version='pr75-check-1ce6ae2ab2c7',partitions=rows)},
    memory_bootstrap=daily_beta.initial_bootstrap())
(root/'source-catalog.json').write_text(json.dumps(snapshot,indent=2)+'\n')
sif_modules.install(snapshot,root/'bundle')
checks_file=daily_beta.check_runtime(root,'gpumd',root/'bundle',root/'fixtures',timeout=900)
checks=json.loads(checks_file.read_text())
report=dict(schema=1,purpose='GPUMD PR 75 isolated SIF/Lmod route qualification',
    passed=all(row['passed'] for row in checks),published=False,original_builds=originals,
    controller_files={p.name:digest(p) for p in (root/'controller').iterdir() if p.is_file()},
    source_sha='1ce6ae2ab2c77a9a155412b44f4f4badc594fd69',checks=checks)
(root/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(passed=report['passed'],published=False,checks=checks)),flush=True)
