#!/bin/bash
bash /home/stardust/sai-hpc-software/deployment/abacus-3.11.0-beta12/submit-native-checks.sh all
result=$?
printf "%s\n" "$result" > /org/org-open-sai/proj-sai-hpc-software/operations/abacus-beta12-installed-20261105-190516/submit.exitcode
exit "$result"
