#pragma once

#include <string>

const std::string global_install_prefix="/opt/apps/deepmd-kit/deepmd-kit-development-master-2026-11-18-ged859426333b-reb7e0498c946/4V100";
const std::string global_git_summ="";
const std::string global_git_hash="ed85942";
const std::string global_git_date="2026-11-18 05:49:36 +0000";
const std::string global_git_branch="HEAD";
const std::string global_tf_include_dir="/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/tensorflow/include;/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/tensorflow/include";
const std::string global_tf_lib="/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/tensorflow/libtensorflow_cc.so.2";
const std::string global_pt_lib="torch;torch_library;/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/torch/lib/libc10.so;/opt/devtools/nvidia/cuda-12.9.1/targets/x86_64-linux/lib/libnvrtc.so;/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/torch/lib/libc10_cuda.so";
const std::string global_pd_lib="";
const std::string global_model_version="1.1 ";
