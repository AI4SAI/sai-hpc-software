// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#ifdef BUILD_PYTORCH
#if __has_include(<torch/csrc/inductor/aoti_package/model_package_loader.h>)
#define BUILD_PT_EXPT_SPIN 1
#else
#define BUILD_PT_EXPT_SPIN 0
#endif

#if BUILD_PT_EXPT_SPIN

#include <torch/torch.h>

#include "DeepSpin.h"

// Forward-declare the temp-file helper from commonPTExpt.h.
namespace deepmd::ptexpt {
class TempFile;
}

namespace torch::inductor {
class AOTIModelPackageLoader;
}

namespace deepmd {
/**
 * @brief PyTorch Exportable (AOTInductor .pt2) implementation for Deep
 *Potential with spin.
 **/
class DeepSpinPTExpt : public DeepSpinBackend {
 public:
  DeepSpinPTExpt();
  virtual ~DeepSpinPTExpt();
  DeepSpinPTExpt(const std::string& model,
                 const int& gpu_rank = 0,
                 const std::string& file_content = "");
  void init(const std::string& model,
            const int& gpu_rank = 0,
            const std::string& file_content = "");

 private:
  /**
   * @brief Evaluate with nlist (LAMMPS path — extended forces).
   **/
  template <typename VALUETYPE, typename ENERGYVTYPE>
  void compute(ENERGYVTYPE& ener,
               std::vector<VALUETYPE>& force,
               std::vector<VALUETYPE>& force_mag,
               std::vector<VALUETYPE>& virial,
               std::vector<VALUETYPE>& atom_energy,
               std::vector<VALUETYPE>& atom_virial,
               const std::vector<VALUETYPE>& coord,
               const std::vector<VALUETYPE>& spin,
               const std::vector<int>& atype,
               const std::vector<VALUETYPE>& box,
               const int nghost,
               const InputNlist& lmp_list,
               const int& ago,
               const std::vector<VALUETYPE>& fparam,
               const std::vector<VALUETYPE>& aparam,
               const std::vector<double>& charge_spin,
               const bool atomic);
  /**
   * @brief Evaluate without nlist (standalone — builds nlist, folds back).
   **/
  template <typename VALUETYPE, typename ENERGYVTYPE>
  void compute(ENERGYVTYPE& ener,
               std::vector<VALUETYPE>& force,
               std::vector<VALUETYPE>& force_mag,
               std::vector<VALUETYPE>& virial,
               std::vector<VALUETYPE>& atom_energy,
               std::vector<VALUETYPE>& atom_virial,
               const std::vector<VALUETYPE>& coord,
               const std::vector<VALUETYPE>& spin,
               const std::vector<int>& atype,
               const std::vector<VALUETYPE>& box,
               const std::vector<VALUETYPE>& fparam,
               const std::vector<VALUETYPE>& aparam,
               const std::vector<double>& charge_spin,
               const bool atomic);

 public:
  double cutoff() const {
    assert(inited);
    return rcut;
  };
  int numb_types() const {
    assert(inited);
    return ntypes;
  };
  int numb_types_spin() const {
    assert(inited);
    return ntypes_spin;
  };
  int dim_fparam() const {
    assert(inited);
    return dfparam;
  };
  int dim_aparam() const {
    assert(inited);
    return daparam;
  };
  int dim_chg_spin() const override {
    assert(inited);
    return dchgspin;
  };
  /**
   * @brief Fix the charge/spin condition served for the rest of the run.
   *
   * It becomes the condition of every later forward pass that is not given
   * one explicitly.  This backend serves models whose lower reads the
   * condition as an ordinary input, so that stored value is the whole
   * mechanism.
   *
   * @param[in] charge_spin The condition, of length ``dim_chg_spin()``.
   **/
  void set_charge_spin(const std::vector<double>& charge_spin) override;
  void get_type_map(std::string& type_map);
  bool is_aparam_nall() const {
    assert(inited);
    return aparam_nall;
  };
  std::vector<bool> get_use_spin() const override {
    assert(inited);
    return use_spin_;
  };
  bool has_default_fparam() const {
    assert(inited);
    return has_default_fparam_;
  };

  // forward to template class (no charge_spin — uses default_chg_spin_
  // fallback)
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& force_mag,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<double>& spin,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& force_mag,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<float>& spin,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& force_mag,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<double>& spin,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& force_mag,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<float>& spin,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const bool atomic);

  // charge_spin overloads — pass runtime charge/spin per call
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& force_mag,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<double>& spin,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& force_mag,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<float>& spin,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& force_mag,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<double>& spin,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& force_mag,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<float>& spin,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;

 private:
  bool inited;
  int ntypes;
  int ntypes_spin;
  int dfparam;
  int daparam;
  int dchgspin;
  bool aparam_nall;
  bool has_default_fparam_;
  std::vector<double> default_fparam_;
  std::vector<double> default_chg_spin_;
  /** Half-open row range of each charge-state value, from the archive. */
  std::vector<std::pair<double, double> > chg_spin_table_ranges_;
  std::vector<bool> use_spin_;
  double rcut;
  int gpu_id;
  bool gpu_enabled;
  std::vector<std::string> type_map;
  std::vector<std::string> output_keys;
  bool do_atomic_virial;  // whether model was exported with atomic virial corr
  // Whether the exported graph consumes the compact edge schema (native spin,
  // shared with DeepPotPTExpt) rather than the deepspin-scheme nlist contract.
  bool lower_input_is_edge_ = false;
  // Whether the exported graph consumes the NeighborGraph schema (native
  // spin; single-rank runs run_model_graph, multi-rank runs
  // run_model_graph_with_comm). Mutually exclusive with lower_input_is_edge_.
  bool lower_input_is_graph_ = false;
  // Edge-vector precision recorded by the .pt2 artifact for the graph route
  // (mirrors DeepPotPTExpt); read from metadata ``graph_edge_dtype``.
  bool graph_edge_fp32_ = false;
  int nnei;  // expected nlist nnei dimension (= sum(sel))
  NeighborListData nlist_data;
  at::Tensor mapping_tensor;         // cached mapping tensor (LAMMPS path)
  at::Tensor firstneigh_tensor;      // cached nlist tensor (LAMMPS path)
  at::Tensor edge_index_tensor;      // cached local-folded edges (edge path)
  at::Tensor edge_index_ext_tensor;  // cached extended edges (edge path)
  std::unique_ptr<torch::inductor::AOTIModelPackageLoader> loader;
  // Optional with-comm artifact for multi-rank GNN spin inference.
  bool has_comm_artifact_ = false;
  // Mirrors descriptor's has_message_passing(). See DeepPotPTExpt.h
  // for the full rationale and gating role.
  bool has_message_passing_ = false;
  // Whether the collective empty-rank preflight (allreduce of the minimum
  // owned+ghost node count over the LAMMPS communicator, native-spin graph
  // with-comm route) has PASSED for the current neighbor topology.  Twin of
  // ``DeepPotPTExpt::graph_comm_preflight_done_``: the preflight re-runs
  // whenever the with-comm graph branch is entered with ``ago == 0`` (every
  // topology rebuild) or before its first success, because the node count
  // shares the lifetime of the cached nlist/mapping/edge topology and
  // re-running the collective on cache-hit (``ago > 0``) force calls would
  // add a global synchronization per MD step with no added protection.
  bool graph_comm_preflight_done_ = false;
  // Model-level pair-type exclusion keep table, built ONCE in ``init`` from
  // the ``pair_exclude_types`` metadata field (see DeepPotPTExpt.h for the
  // full rationale).  UNDEFINED => no exclusion (identity).  Applied at the
  // neighbor-graph BUILD seam (``applyPairExclusion``), never inside the
  // exported lower.
  torch::Tensor pair_exclude_table_;
  std::unique_ptr<deepmd::ptexpt::TempFile> with_comm_tempfile_;
  std::unique_ptr<torch::inductor::AOTIModelPackageLoader> with_comm_loader;

  std::vector<torch::Tensor> run_model(const torch::Tensor& coord,
                                       const torch::Tensor& atype,
                                       const torch::Tensor& spin,
                                       const torch::Tensor& nlist,
                                       const torch::Tensor& mapping,
                                       const torch::Tensor& fparam,
                                       const torch::Tensor& aparam,
                                       const torch::Tensor& charge_spin);

  /**
   * @brief Run the native-spin edge artifact: the energy edge schema plus the
   * per-local-atom spin leaf.
   */
  std::vector<torch::Tensor> run_model_edges(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_scatter_index,
      const torch::Tensor& edge_mask,
      const torch::Tensor& spin,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin);

  /**
   * @brief Run the native-spin NeighborGraph artifact: the 10 base graph
   * tensors (see commonPT.h GraphTensorPack), the per-node spin leaf
   * (always present, positional index 10), then the conditional
   * fparam/aparam/charge_spin tail -- combined native-spin + charge-spin
   * FiLM models carry charge_spin at slot 13, mirroring the energy graph
   * ABI's optional charge_spin tail.  Single-rank; the multi-rank twin is
   * ``run_model_graph_with_comm``.
   */
  std::vector<torch::Tensor> run_model_graph(
      const torch::Tensor& atype,
      const torch::Tensor& n_node,
      const torch::Tensor& n_local,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_mask,
      const torch::Tensor& destination_order,
      const torch::Tensor& destination_row_ptr,
      const torch::Tensor& source_order,
      const torch::Tensor& source_row_ptr,
      const torch::Tensor& spin,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin);

  /**
   * @brief Run the native-spin parallel GRAPH artifact: run_model_graph's
   * ABI (spin at positional index 10) with the 8 border_op comm tensors
   * appended after the conditional fparam/aparam/charge_spin tail.
   *
   * ``spin`` is the EXTENDED per-node spin -- ghost rows carry their
   * owner's value from the LAMMPS ``sp`` forward-comm, so spin itself needs
   * no cross-rank exchange; only the per-block ghost FEATURE refresh rides
   * ``border_op``.  Twin of ``DeepPotPTExpt::run_model_graph_with_comm``.
   */
  std::vector<torch::Tensor> run_model_graph_with_comm(
      const torch::Tensor& atype,
      const torch::Tensor& n_node,
      const torch::Tensor& n_local,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_mask,
      const torch::Tensor& destination_order,
      const torch::Tensor& destination_row_ptr,
      const torch::Tensor& source_order,
      const torch::Tensor& source_row_ptr,
      const torch::Tensor& spin,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  /**
   * @brief Run the native-spin parallel edge artifact: the energy edge
   * with-comm schema (coord and extended types span the extended node set)
   * plus the EXTENDED per-node spin leaf, then the 8 border_op comm tensors.
   */
  std::vector<torch::Tensor> run_model_edges_with_comm(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& extended_atype,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_scatter_index,
      const torch::Tensor& edge_mask,
      const torch::Tensor& spin,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  /**
   * @brief Run with-comm spin artifact: 5-8 base inputs (incl.
   * extended_spin) + 8 comm tensors.
   */
  std::vector<torch::Tensor> run_model_with_comm(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& spin,
      const torch::Tensor& nlist,
      const torch::Tensor& mapping,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  void extract_outputs(std::map<std::string, torch::Tensor>& output_map,
                       const std::vector<torch::Tensor>& flat_outputs);

  void translate_error(std::function<void()> f);
};

}  // namespace deepmd

#endif  // BUILD_PT_EXPT_SPIN
#endif  // BUILD_PYTORCH
