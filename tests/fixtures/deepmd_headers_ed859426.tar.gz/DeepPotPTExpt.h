// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#ifdef BUILD_PYTORCH
// AOTInductor package loader requires a header that may not exist on all
// platforms (e.g. macOS x86_64).  Disable pt_expt support when missing.
#if __has_include(<torch/csrc/inductor/aoti_package/model_package_loader.h>)
#define BUILD_PT_EXPT 1
#else
#define BUILD_PT_EXPT 0
#endif

#if BUILD_PT_EXPT

#include <torch/torch.h>

#include <array>
#include <cstdint>
#include <mutex>
#include <optional>

#include "DeepPot.h"
#include "graph_assembly.h"

// Forward-declare to keep these out of the public header. Defined in
// commonPTExpt.h, and PinnedCell in longRangePTExpt.h.
namespace deepmd::ptexpt {
class TempFile;
class ChargeStateFold;
class GraphReplay;
class PinnedCell;
struct HaloTensors;
}  // namespace deepmd::ptexpt

namespace torch::inductor {
class AOTIModelPackageLoader;
}

namespace deepmd {
/**
 * @brief PyTorch Exportable (AOTInductor .pt2) implementation for Deep
 *Potential.
 **/
class DeepPotPTExpt : public DeepPotBackend {
 public:
  /**
   * @brief DP constructor without initialization.
   **/
  DeepPotPTExpt();
  virtual ~DeepPotPTExpt();
  /**
   * @brief DP constructor with initialization.
   * @param[in] model The name of the .pt2 model file.
   * @param[in] gpu_rank The GPU rank. Default is 0.
   * @param[in] file_content The content of the model file. If it is not empty,
   *DP will read from the string instead of the file.
   **/
  DeepPotPTExpt(const std::string& model,
                const int& gpu_rank = 0,
                const std::string& file_content = "");
  /**
   * @brief Initialize the DP.
   * @param[in] model The name of the .pt2 model file.
   * @param[in] gpu_rank The GPU rank. Default is 0.
   * @param[in] file_content The content of the model file. If it is not empty,
   *DP will read from the string instead of the file.
   **/
  void init(const std::string& model,
            const int& gpu_rank = 0,
            const std::string& file_content = "");

 private:
  /**
   * @brief Evaluate with nlist (LAMMPS path — extended forces).
   **/
  template <typename VALUETYPE, typename ENERGYVTYPE>
  void compute(ENERGYVTYPE& ener,
               std::vector<VALUETYPE>& force,
               std::vector<VALUETYPE>& virial,
               std::vector<VALUETYPE>& atom_energy,
               std::vector<VALUETYPE>& atom_virial,
               const std::vector<VALUETYPE>& coord,
               const std::vector<int>& atype,
               const std::vector<VALUETYPE>& box,
               const int nghost,
               const InputNlist& lmp_list,
               const int& ago,
               const std::vector<VALUETYPE>& fparam,
               const std::vector<VALUETYPE>& aparam,
               const std::vector<double>& charge_spin,
               const bool atomic);
  /**
   * @brief Evaluate without nlist (standalone — builds nlist, folds back).
   **/
  template <typename VALUETYPE, typename ENERGYVTYPE>
  void compute(ENERGYVTYPE& ener,
               std::vector<VALUETYPE>& force,
               std::vector<VALUETYPE>& virial,
               std::vector<VALUETYPE>& atom_energy,
               std::vector<VALUETYPE>& atom_virial,
               const std::vector<VALUETYPE>& coord,
               const std::vector<int>& atype,
               const std::vector<VALUETYPE>& box,
               const std::vector<VALUETYPE>& fparam,
               const std::vector<VALUETYPE>& aparam,
               const std::vector<double>& charge_spin,
               const bool atomic);

 public:
  double cutoff() const {
    assert(inited);
    return rcut;
  };
  int numb_types() const {
    assert(inited);
    return ntypes;
  };
  int numb_types_spin() const {
    assert(inited);
    return 0;
  };
  int dim_fparam() const {
    assert(inited);
    return dfparam;
  };
  int dim_aparam() const {
    assert(inited);
    return daparam;
  };
  /**
   * @brief The width of a charge/spin condition this model accepts.
   *
   * This is the width a caller names a condition with, which is not in
   * general the width of the conditioning input of the compiled forward:
   * compression folds the condition into frozen tables and so removes it from
   * the argument list, leaving a model that still serves a condition through
   * the fold shipped beside the inference lower.
   **/
  int dim_chg_spin() const override {
    assert(inited);
    return settable_chgspin;
  };
  /**
   * @brief Fix the charge/spin condition served for the rest of the run.
   *
   * The condition reaches the model by one of two routes, and this sets both
   * so that the caller does not depend on how the model was frozen.  It
   * becomes the condition of every later forward pass that is not given one
   * explicitly.  A compressed descriptor additionally carries the condition
   * inside frozen tables that the compiled lower holds as constants; when the
   * archive ships the fold that rebuilds them, it runs here and the resulting
   * tables are written over those constants.
   *
   * Intended to be called once, before inference, since overwriting the
   * constants of a loaded module is not safe to interleave with a forward
   * pass.
   *
   * @param[in] charge_spin The condition, of length ``dim_chg_spin()``.
   **/
  void set_charge_spin(const std::vector<double>& charge_spin) override;
  void get_type_map(std::string& type_map);
  bool is_aparam_nall() const {
    assert(inited);
    return aparam_nall;
  };
  bool has_default_fparam() const {
    assert(inited);
    return has_default_fparam_;
  };

  // forward to template class (no charge_spin — uses default_chg_spin_
  // fallback)
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const bool atomic);
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const bool atomic);
  void computew_mixed_type(std::vector<double>& ener,
                           std::vector<double>& force,
                           std::vector<double>& virial,
                           std::vector<double>& atom_energy,
                           std::vector<double>& atom_virial,
                           const int& nframes,
                           const std::vector<double>& coord,
                           const std::vector<int>& atype,
                           const std::vector<double>& box,
                           const std::vector<double>& fparam,
                           const std::vector<double>& aparam,
                           const bool atomic);
  void computew_mixed_type(std::vector<double>& ener,
                           std::vector<float>& force,
                           std::vector<float>& virial,
                           std::vector<float>& atom_energy,
                           std::vector<float>& atom_virial,
                           const int& nframes,
                           const std::vector<float>& coord,
                           const std::vector<int>& atype,
                           const std::vector<float>& box,
                           const std::vector<float>& fparam,
                           const std::vector<float>& aparam,
                           const bool atomic);

  // charge_spin overloads — pass runtime charge/spin per call
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<double>& force,
                std::vector<double>& virial,
                std::vector<double>& atom_energy,
                std::vector<double>& atom_virial,
                const std::vector<double>& coord,
                const std::vector<int>& atype,
                const std::vector<double>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<double>& fparam,
                const std::vector<double>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew(std::vector<double>& ener,
                std::vector<float>& force,
                std::vector<float>& virial,
                std::vector<float>& atom_energy,
                std::vector<float>& atom_virial,
                const std::vector<float>& coord,
                const std::vector<int>& atype,
                const std::vector<float>& box,
                const int nghost,
                const InputNlist& inlist,
                const int& ago,
                const std::vector<float>& fparam,
                const std::vector<float>& aparam,
                const std::vector<double>& charge_spin,
                const bool atomic) override;
  void computew_mixed_type(std::vector<double>& ener,
                           std::vector<double>& force,
                           std::vector<double>& virial,
                           std::vector<double>& atom_energy,
                           std::vector<double>& atom_virial,
                           const int& nframes,
                           const std::vector<double>& coord,
                           const std::vector<int>& atype,
                           const std::vector<double>& box,
                           const std::vector<double>& fparam,
                           const std::vector<double>& aparam,
                           const std::vector<double>& charge_spin,
                           const bool atomic) override;
  void computew_mixed_type(std::vector<double>& ener,
                           std::vector<float>& force,
                           std::vector<float>& virial,
                           std::vector<float>& atom_energy,
                           std::vector<float>& atom_virial,
                           const int& nframes,
                           const std::vector<float>& coord,
                           const std::vector<int>& atype,
                           const std::vector<float>& box,
                           const std::vector<float>& fparam,
                           const std::vector<float>& aparam,
                           const std::vector<double>& charge_spin,
                           const bool atomic) override;

  /** @brief Compatibility overload using stored frame and atomic parameters. */
  void compute_edges_gpu(double* d_atom_energy,
                         double* d_force,
                         double* d_atom_virial,
                         const double* d_coord,
                         const int* d_atype,
                         const int* d_edge_index,
                         const double* d_edge_vec,
                         const int nloc,
                         const int nedge) override;

  /**
   * @brief Fully device-resident inference for exported edge-input or
   * graph-input .pt2 models.
   *
   * Runs the exported model directly on a GPU-built compact edge schema,
   * keeping coordinates, the edge graph and the outputs on the device.  All
   * pointers reference GPU memory on the model's device.  ``edge_index`` is the
   * flattened [2, nedge] edge graph (row 0 = neighbor/source, row 1 =
   * center/destination); ``edge_vec`` is the matching minimum-image bond vector
   * ``r_neighbor - r_center``.  Outputs are written device-to-device.
   *
   * @param[out] d_atom_energy Per-atom energy, GPU [nloc].
   * @param[out] d_force Per-node force, GPU [nall_nodes * 3] row-major.
   * @param[out] d_atom_virial Per-node virial, GPU [nall_nodes * 9] row-major.
   * @param[in] d_coord Coordinates, GPU [nall_nodes * 3] row-major.
   * @param[in] d_atype Atom types, GPU [nall_nodes].
   * @param[in] d_edge_index Destination-major [source, destination] edge graph,
   *   GPU [2 * nedge].
   * @param[in] d_edge_vec Minimum-image bond vectors, GPU [nedge * 3].
   * @param[in] nloc Number of local atoms.
   * @param[in] nedge Number of physical edges (dummy edges added internally).
   * @param[in] fparam Host-resident frame parameters, or empty for the stored
   *   default.
   * @param[in] aparam Host-resident per-atom parameters, or empty for none.
   * @param[in] nall_nodes Graph node count: 0 (or nloc) folds ghosts onto local
   *   owners; nall_nodes > nloc keeps the extended (local + ghost) node set.
   * @param[in] comm_nlist Communication neighbor list for the extended node
   * set; required by a message-passing model under domain decomposition,
   * nullptr otherwise.
   */
  void compute_edges_gpu(double* d_atom_energy,
                         double* d_force,
                         double* d_atom_virial,
                         const double* d_coord,
                         const int* d_atype,
                         const int* d_edge_index,
                         const double* d_edge_vec,
                         const int nloc,
                         const int nedge,
                         const std::vector<double>& fparam,
                         const std::vector<double>& aparam,
                         const int nall_nodes,
                         const InputNlist* comm_nlist) override;
  void compute_canonical_graph_gpu(double* d_atom_energy,
                                   double* d_force,
                                   double* d_virial,
                                   double* d_atom_virial,
                                   const std::int64_t* d_atype,
                                   const void* d_source,
                                   DP_CanonicalIndexWidth index_width,
                                   const float* d_edge_vec,
                                   const std::int64_t* d_destination_row_ptr,
                                   const std::int64_t* d_source_row_ptr,
                                   const std::int64_t* d_source_order,
                                   const double* d_coord,
                                   void* world,
                                   const DP_HaloExchange* halo,
                                   const double* box,
                                   const std::int64_t nloc,
                                   const std::int64_t nall_nodes,
                                   const std::int64_t edge_storage,
                                   void* stream) override;
  /**
   * @brief FP32 edge-vector overload for compressed graph artifacts.
   *
   * The model metadata must declare ``graph_edge_dtype == "float32"``. The
   * remaining graph and output contracts are identical to the FP64 overload.
   */
  void compute_edges_gpu(double* d_atom_energy,
                         double* d_force,
                         double* d_atom_virial,
                         const double* d_coord,
                         const int* d_atype,
                         const int* d_edge_index,
                         const float* d_edge_vec,
                         const int nloc,
                         const int nedge,
                         const std::vector<double>& fparam,
                         const std::vector<double>& aparam,
                         const int nall_nodes,
                         const InputNlist* comm_nlist) override;
  /**
   * @brief Whether the loaded artifact accepts the device-edge API.
   */
  bool supports_device_edge_inference() const override;
  /**
   * @brief Whether the loaded graph artifact consumes FP32 edge vectors.
   */
  bool uses_fp32_edge_vectors() const override;
  bool uses_canonical_graph_inference() const override;
  bool canonical_graph_requires_source_csr() const override;
  bool canonical_graph_requires_halo() const override;
  bool has_long_range() const override;

 private:
  template <typename EDGE_TYPE>
  void compute_edges_gpu_impl(double* d_atom_energy,
                              double* d_force,
                              double* d_atom_virial,
                              const double* d_coord,
                              const int* d_atype,
                              const int* d_edge_index,
                              const EDGE_TYPE* d_edge_vec,
                              const int nloc,
                              const int nedge,
                              const std::vector<double>& fparam,
                              const std::vector<double>& aparam,
                              const int nall_nodes,
                              const InputNlist* comm_nlist);
  void compute_canonical_graph_gpu_impl(
      double* d_atom_energy,
      double* d_force,
      double* d_virial,
      double* d_atom_virial,
      const std::int64_t* d_atype,
      const void* d_source,
      DP_CanonicalIndexWidth index_width,
      const float* d_edge_vec,
      const std::int64_t* d_destination_row_ptr,
      const std::int64_t* d_source_row_ptr,
      const std::int64_t* d_source_order,
      const double* d_coord,
      void* world,
      const DP_HaloExchange* halo,
      const double* box,
      const std::int64_t nloc,
      const std::int64_t nall_nodes,
      const std::int64_t edge_storage,
      void* stream);
  bool inited;
  // Every width below is a property of the loaded archive.  They read as zero
  // until ``init`` has run, so that a query on an uninitialised backend
  // answers "none" rather than whatever the allocation happened to hold.
  int ntypes = 0;
  int dfparam = 0;
  int daparam = 0;
  // Conditioning width of the compiled forward's argument list.  Zero for a
  // model that carries no condition, and also for a compressed one, whose
  // condition lives in frozen tables rather than in an input.  Every gate that
  // decides whether to hand the forward a condition tensor reads this.
  int dchgspin = 0;
  // Width of a charge state this model can be given; see ``dim_chg_spin()``.
  int settable_chgspin = 0;
  bool aparam_nall;
  bool has_default_fparam_;
  std::vector<double> default_fparam_;
  std::vector<double> default_chg_spin_;
  /** Half-open row range of each charge-state value, from the archive. */
  std::vector<std::pair<double, double> > chg_spin_table_ranges_;
  double rcut;
  int gpu_id;
  bool gpu_enabled;
  std::vector<std::string> type_map;
  std::vector<std::string> output_keys;  // sorted internal output key names
  bool do_atomic_virial;  // whether model was exported with atomic virial corr
  int nnei;               // expected nlist nnei dimension (= sum(sel))
  bool lower_input_is_edge_ = false;
  bool lower_input_is_graph_ = false;
  bool lower_input_is_canonical_ = false;
  // Whether the canonical force assembly groups edges by source, which makes
  // the source CSR an input of every evaluation rather than of the per-atom
  // virial alone.
  bool canonical_requires_source_csr_ = false;
  // Two-entry source CSR placeholders that decline the per-atom virial.
  at::Tensor source_row_placeholder_;
  at::Tensor source_order_placeholder_;
  bool graph_edge_fp32_ = false;
  // The model carries a long-range module, whose lower reads the topologies
  // of the frame after its other inputs: the pair lists, and the mesh of the
  // cell of a module that serves periodic systems, for the graph lower; the
  // node positions, the communicator of the ranks and the cell for the compact
  // canonical lower.
  bool long_range_ = false;
  // The module serves periodic systems, on a mesh of at most this spacing.
  bool long_range_periodic_ = false;
  double mesh_spacing_ = 0.0;
  NeighborListData nlist_data;
  at::Tensor mapping_tensor;           // cached mapping tensor (LAMMPS path)
  std::vector<std::int64_t> mapping_;  // cached mapping vector (LAMMPS path)
  at::Tensor firstneigh_tensor;        // cached nlist tensor (LAMMPS path)
  at::Tensor edge_index_tensor;        // cached local edge graph (LAMMPS path)
  at::Tensor edge_index_ext_tensor;  // cached extended edge graph (LAMMPS path)
  std::unique_ptr<torch::inductor::AOTIModelPackageLoader> loader;
  // The cell input of the device-resident evaluations of a model with a
  // long-range module, in pinned memory that a replay reads again.
  std::unique_ptr<deepmd::ptexpt::PinnedCell> long_range_cell_;
  // The mesh size of the cell of the last device-resident evaluation of a
  // model with a long-range module, zero for a non-periodic frame, and the
  // evaluations since it last changed, counted up to the number of calls for
  // which a changed mesh is evaluated eagerly before it is captured again.
  std::optional<std::array<std::int64_t, 3> > long_range_mesh_;
  std::int64_t long_range_mesh_calls_ = 0;
  // CUDA-graph replay of repeated device-resident canonical evaluations,
  // declared after the loader and the cell so that the graph is released
  // before the constants and the cell it reads.
  std::unique_ptr<deepmd::ptexpt::GraphReplay> canonical_replay_;
  // Serializes the runs of the model, which runs on a single-threaded runner,
  // the device-resident entry points, whose replay of canonical evaluations
  // keeps its graph across calls, and the replacement of the constants. The
  // mutex is recursive because a replayed evaluation enters the runner again.
  std::recursive_mutex evaluation_mutex_;
  // Optional AOTInductor artifact for multi-rank message-passing inference,
  // loaded only when the .pt2 metadata declares ``has_comm_artifact``. It is
  // required when ghost features must be exchanged across ranks inside the
  // forward pass.  ``with_comm_tempfile_`` owns the extracted nested .pt2 for
  // the lifetime of ``with_comm_loader``.
  bool has_comm_artifact_ = false;
  // Whether the regular .pt2 graph consumes the mapping tensor to gather ghost
  // features, i.e. the descriptor performs message passing.  Read from the
  // ``has_message_passing`` metadata field; archives without it default to
  // non-message-passing.
  bool has_message_passing_ = false;
  // Whether the collective empty-rank preflight (allreduce of the minimum
  // owned+ghost node count over the LAMMPS communicator, graph with-comm
  // route) has PASSED for the current neighbor topology.  The preflight
  // re-runs whenever the with-comm graph branch is entered with
  // ``ago == 0`` (every topology rebuild) or before its first success:
  // the node count shares the lifetime of the cached nlist/mapping/edge
  // topology, so re-running the collective on cache-hit (``ago > 0``)
  // force calls added a global synchronization per MD step without any
  // added protection.
  bool graph_comm_preflight_done_ = false;
  // Device-resident (ntypes+1)^2 model-level pair-type keep table, uploaded
  // ONCE in ``init`` from the ``pair_exclude_types`` metadata field (see
  // ``deepmd::buildPairExcludeTable``).  An UNDEFINED tensor => no model-level
  // exclusion (identity).  The device is fixed at ``init`` (``gpu_id`` /
  // ``gpu_enabled``), so the seam helpers ``index_select`` it directly with no
  // per-step CPU clone / H2D upload.  Exclusion is a BUILD-time transform
  // (decision #18/A4): the C++ ingestion seam is the single application site
  // (``applyPairExclusion`` graph / ``applyPairExclusionNlist`` dense); the
  // exported .pt2 lowers consume pre-excluded inputs and never re-apply it.
  torch::Tensor pair_exclude_table_;
  // Host copy of the same table. The graph route folds the exclusion into the
  // per-edge assembly predicate, so an excluded edge is never allocated; that
  // predicate runs on the host, before the payload reaches the model device.
  std::vector<int> pair_exclude_host_;
  // Destination-grouped skin topology, rebuilt only when the host rebuilds its
  // neighbor list, and the row-pointer scratch the per-step assembly reuses.
  deepmd::SkinTopology skin_topology_;
  deepmd::GraphAssemblyScratch graph_scratch_;
  // Whether the compiled graph lower reads the source-major permutation.
  // Recorded by the artifact (``graph_source_csr``); absent metadata means the
  // permutation is built, which is always correct.
  bool graph_reads_source_csr_ = true;
  std::unique_ptr<deepmd::ptexpt::TempFile> with_comm_tempfile_;
  std::unique_ptr<torch::inductor::AOTIModelPackageLoader> with_comm_loader;
  // The charge/spin condition a compressed descriptor folded into the
  // constants of its lower, re-runnable so that a condition chosen at runtime
  // can be served.  Null for an uncompressed model, which reads its condition
  // as an ordinary input and needs no rebuild.
  std::unique_ptr<deepmd::ptexpt::ChargeStateFold> charge_state_fold_;

  /**
   * @brief Multi-frame loop for standalone compute (no nlist).
   */
  template <typename VALUETYPE, typename ENERGYVTYPE>
  void compute_nframes(ENERGYVTYPE& ener,
                       std::vector<VALUETYPE>& force,
                       std::vector<VALUETYPE>& virial,
                       std::vector<VALUETYPE>& atom_energy,
                       std::vector<VALUETYPE>& atom_virial,
                       const int nframes,
                       const std::vector<VALUETYPE>& coord,
                       const std::vector<int>& atype,
                       const std::vector<VALUETYPE>& box,
                       const std::vector<VALUETYPE>& fparam,
                       const std::vector<VALUETYPE>& aparam,
                       const std::vector<double>& charge_spin,
                       const bool atomic);

  /**
   * @brief Mixed-type compute implementation (loops over frames).
   */
  template <typename VALUETYPE>
  void compute_mixed_type_impl(std::vector<double>& ener,
                               std::vector<VALUETYPE>& force,
                               std::vector<VALUETYPE>& virial,
                               std::vector<VALUETYPE>& atom_energy,
                               std::vector<VALUETYPE>& atom_virial,
                               const int& nframes,
                               const std::vector<VALUETYPE>& coord,
                               const std::vector<int>& atype,
                               const std::vector<VALUETYPE>& box,
                               const std::vector<VALUETYPE>& fparam,
                               const std::vector<VALUETYPE>& aparam,
                               const std::vector<double>& charge_spin,
                               const bool atomic);

  /**
   * @brief Run the .pt2 model and return flat output tensors.
   * @param[in] coord Extended coordinates tensor.
   * @param[in] atype Extended atom types tensor.
   * @param[in] nlist Neighbor list tensor.
   * @param[in] mapping Mapping tensor.
   * @param[in] fparam Frame parameter tensor (or empty).
   * @param[in] aparam Atomic parameter tensor (or empty).
   * @param[in] charge_spin Charge/spin tensor (or empty).
   * @return Vector of output tensors in sorted key order.
   */
  std::vector<torch::Tensor> run_model(const torch::Tensor& coord,
                                       const torch::Tensor& atype,
                                       const torch::Tensor& nlist,
                                       const torch::Tensor& mapping,
                                       const torch::Tensor& fparam,
                                       const torch::Tensor& aparam,
                                       const torch::Tensor& charge_spin);

  std::vector<torch::Tensor> run_model_edges(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_scatter_index,
      const torch::Tensor& edge_mask,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin);

  /**
   * @brief Run a graph-input ``.pt2`` artifact (lower_input_kind="graph").
   *
   * Positional AOTI input order matches the Python export ABI:
   * ``(atype, n_node, n_local, edge_index, edge_vec, edge_mask,
   * destination_order, destination_row_ptr, source_order, source_row_ptr,
   * [fparam], [aparam], [charge_spin])``.
   *
   * @param[in] atype Per-node local-plus-halo types, shape ``(N,)`` int64.
   * @param[in] n_node Per-frame total node count, shape ``(nf,)`` int64.
   * @param[in] n_local Per-frame owned node count, shape ``(nf,)`` int64.
   * @param[in] edge_index Folded edge graph ``(2, E)`` int64 [src, dst].
   * @param[in] edge_vec Edge vectors ``(E, 3)`` (neighbour - center).
   * @param[in] edge_mask Physical-edge mask ``(E,)`` bool.
   * @param[in] destination_order Destination-grouped edge permutation ``(E,)``.
   * @param[in] destination_row_ptr Destination CSR offsets ``(N + 1,)``.
   * @param[in] source_order Source-grouped edge permutation ``(E,)``.
   * @param[in] source_row_ptr Source CSR offsets ``(N + 1,)``.
   * @param[in] coord Positions of the nodes of the single frame, shape
   * ``(N, 3)`` float64, from which the topologies of a model with a
   * long-range module are built; read only for such a model.
   * @param[in] box The row-major cell of a periodic frame, nine values, or
   * empty for a non-periodic one; read only for such a model.
   */
  std::vector<torch::Tensor> run_model_graph(
      const torch::Tensor& atype,
      const torch::Tensor& n_node,
      const torch::Tensor& n_local,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_mask,
      const torch::Tensor& destination_order,
      const torch::Tensor& destination_row_ptr,
      const torch::Tensor& source_order,
      const torch::Tensor& source_row_ptr,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const torch::Tensor& coord,
      const std::vector<double>& box);

  /**
   * @brief Run a compact canonical ``.pt2`` artifact.
   *
   * @param[in] coord Node positions, shape ``(N, 3)`` float64, appended for a
   * model with a long-range module and ignored otherwise.
   * @param[in] world The MPI communicator (a pointer to an ``MPI_Comm``) of the
   * ranks a decomposed system spans, or NULL for a system that one rank holds
   * whole; a model with a long-range module receives it after the positions,
   * and a model with further message-passing blocks before its halo exchange.
   * @param[in] cell The cell, a float64 CPU tensor of shape ``(1, 9)``: the
   * row-major cell of a periodic frame, or zero for a non-periodic one; a
   * model with a long-range module receives it after the communicator, and
   * every other model ignores it.
   * @param[in] halo The halo exchange of the node set, which a model with
   * further message-passing blocks receives after the communicator and every
   * other model ignores.
   */
  std::vector<torch::Tensor> run_model_canonical_graph(
      const torch::Tensor& atype,
      const torch::Tensor& n_node,
      const torch::Tensor& n_local,
      const torch::Tensor& source,
      const torch::Tensor& edge_vec,
      const torch::Tensor& destination_row_ptr,
      const torch::Tensor& source_row_ptr,
      const torch::Tensor& source_order,
      const torch::Tensor& coord,
      const void* world,
      const torch::Tensor& cell,
      const ptexpt::HaloTensors& halo);

  /**
   * @brief Evaluate the long-range module on a rank that holds no node.
   *
   * The compact lower runs on one halo node without edges, which carries no
   * charge and contributes nothing, so that the rank joins the exchanges of
   * the module with the other ranks of ``world``, in the cell ``box`` of the
   * system, empty for a non-periodic one.
   */
  void join_long_range_exchange(const void* world,
                                const std::vector<double>& box);

  /**
   * @brief Check the cell given to a model with a long-range module.
   *
   * @param[in] box The row-major cell of a periodic frame, nine values, or
   * empty for a non-periodic one, which every long-range module serves; a
   * cell requires a module that serves periodic systems.
   */
  void check_long_range_box(const std::vector<double>& box) const;

  /**
   * @brief Run the with-comm .pt2 artifact with comm tensors appended.
   *
   * @param[in] base 4-6 base inputs (coord, atype, nlist, mapping,
   *            fparam?, aparam?) — same as ``run_model``.
   * @param[in] charge_spin Charge/spin tensor (or empty).
   * @param[in] comm_tensors 8 comm tensors in canonical positional
   *            order: send_list, send_proc, recv_proc, send_num,
   *            recv_num, communicator, nlocal, nghost.
   */
  std::vector<torch::Tensor> run_model_with_comm(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& nlist,
      const torch::Tensor& mapping,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  /**
   * @brief Run the with-comm edge-input ``.pt2`` artifact with comm tensors.
   *
   * The edge schema indexes the extended node set, so ``edge_index`` and
   * ``edge_scatter_index`` coincide. ``atype`` carries owned atoms (fitting,
   * energy read-out) while ``extended_atype`` embeds ghost neighbours.
   *
   * @param[in] comm_tensors 8 comm tensors in canonical positional order:
   *            send_list, send_proc, recv_proc, send_num, recv_num,
   *            communicator, nlocal, nghost.
   */
  std::vector<torch::Tensor> run_model_edges_with_comm(
      const torch::Tensor& coord,
      const torch::Tensor& atype,
      const torch::Tensor& extended_atype,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_scatter_index,
      const torch::Tensor& edge_mask,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  /**
   * @brief Run the with-comm NeighborGraph (message-passing, e.g. DPA2/DPA3)
   *        ``.pt2`` artifact with comm tensors appended.
   *
   * Positional AOTI input order mirrors ``run_model_graph``: ``(atype,
   * n_node, n_local, edge_index, edge_vec, edge_mask, destination_order,
   * destination_row_ptr, source_order, source_row_ptr, [fparam], [aparam],
   * [charge_spin], comm_tensors...)``.  The graph is built on the
   * EXTENDED region (``fold_to_local=false``): ghost nodes are distinct and
   * their embeddings are filled in-place by ``border_op`` inside the
   * exported artifact, exactly as the with-comm dense/edge artifacts do.
   *
   * @param[in] atype Per-node extended-region types, shape ``(N,)`` int64,
   *            N == nall_real (owned prefix first, then ghost).
   * @param[in] n_node Per-frame node count, shape ``(nf,)`` int64.
   * @param[in] edge_index Extended-region edge graph ``(2, E)`` int64
   *            [src, dst]; ghost-node indices retained (NOT folded to
   *            owners -- ``fold_to_local=false``).
   * @param[in] edge_vec Edge vectors ``(E, 3)`` (neighbour - center).
   * @param[in] edge_mask Physical-edge mask ``(E,)`` bool.
   * @param[in] aparam Atomic parameters on the flat EXTENDED node axis,
   *            shape ``(N, dim_aparam)`` (owned prefix filled, ghost rows
   *            zero-padded -- ghost fitting outputs are masked inside the
   *            artifact), or an empty tensor when ``dim_aparam == 0``.
   * @param[in] comm_tensors 8 comm tensors in canonical positional order:
   *            send_list, send_proc, recv_proc, send_num, recv_num,
   *            communicator, nlocal, nghost.  All 8 stay on CPU (host
   *            control metadata for the opaque ``border_op``, symmetric
   *            with the dense with-comm artifact).
   * @param[in] n_local (1,) int64 owned-node count consumed IN-GRAPH by the
   *            owned-node energy mask; moved to the model device here (its
   *            consumer is a device kernel after ``move_to_device_pass``).
   *            Same value as the ``nlocal`` comm tensor -- the two inputs
   *            separate the device-compute role from the host-MPI-control
   *            role, so ``border_op`` never pulls device scalars.
   */
  std::vector<torch::Tensor> run_model_graph_with_comm(
      const torch::Tensor& atype,
      const torch::Tensor& n_node,
      const torch::Tensor& n_local,
      const torch::Tensor& edge_index,
      const torch::Tensor& edge_vec,
      const torch::Tensor& edge_mask,
      const torch::Tensor& destination_order,
      const torch::Tensor& destination_row_ptr,
      const torch::Tensor& source_order,
      const torch::Tensor& source_row_ptr,
      const torch::Tensor& fparam,
      const torch::Tensor& aparam,
      const torch::Tensor& charge_spin,
      const std::vector<at::Tensor>& comm_tensors);

  /**
   * @brief Extract outputs from flat tensor list using output_keys.
   */
  void extract_outputs(std::map<std::string, torch::Tensor>& output_map,
                       const std::vector<torch::Tensor>& flat_outputs);

  /**
   * @brief Translate PyTorch exceptions to DeePMD-kit exceptions.
   */
  void translate_error(std::function<void()> f);
};

}  // namespace deepmd

#endif  // BUILD_PT_EXPT
#endif  // BUILD_PYTORCH
