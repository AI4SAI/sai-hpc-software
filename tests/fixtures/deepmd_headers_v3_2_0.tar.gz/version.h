#pragma once

#include <string>

const std::string global_install_prefix="/opt/apps/conda_env/deepmd-kit-3.2.0";
const std::string global_git_summ="";
const std::string global_git_hash="";
const std::string global_git_date="";
const std::string global_git_branch="";
const std::string global_tf_include_dir="";
const std::string global_tf_lib="";
const std::string global_pt_lib="torch;torch_library;/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/torch/lib/libc10.so;/opt/devtools/nvidia/cuda-12.6.3/lib64/libnvrtc.so;/opt/apps/conda_env/deepmd-kit-3.2.0/lib/python3.13/site-packages/torch/lib/libc10_cuda.so";
const std::string global_pd_lib="";
const std::string global_model_version="1.1 ";
